package com.manulfe.xltocsv;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ConvertExceltoCsv {
	
	
	
	static private String encodeValue(String value,String delmiter) {
	    boolean needQuotes = false;
	   
	    	value =value.replaceAll("\"","");
	    	//value =value.replaceAll("'","");
	    	value=value.replaceAll("\n", " ");
	    
	
	    if (value.indexOf(delmiter) != -1)
	        needQuotes = true;
	   
	      
	    
	    if ( needQuotes ) return "\"" + value + "\"";
	    else return value;
	}
	
public static void main(String[] args) throws IOException{
	String path = args[0];
	String delimiter = args[1];
	FileInputStream fis = new FileInputStream(path);
	Workbook wb = new XSSFWorkbook(fis);
	DataFormatter formatter = new DataFormatter();
	//PrintStream out = new PrintStream(new FileOutputStream("C:\\Hadoop_Input\\Pig_Input\\x.csv"),true, "UTF-8");
	int numberOfSheets = wb.getNumberOfSheets();
	//byte[] bom = {(byte)0xEF, (byte)0xBB, (byte)0xBF};
	FormulaEvaluator fe = null;
	int numCols_F = 0;
	

    Sheet sheet = wb.getSheetAt(0);
    for (int r = 0, rn = sheet.getLastRowNum() ; r <= rn ; r++) {
        Row row = sheet.getRow(r);
        int numCols=row.getLastCellNum();
        StringBuffer sb = new StringBuffer();
        
        if(r==0){
        	
        	numCols_F=row.getLastCellNum();
        	
        }
        
        int col_missing=numCols_F-numCols;
        if ( row == null ) { System.out.println(delimiter); continue; }
        boolean firstCell = true;
        boolean lastCell = false;
        for (int c = 0, cn = row.getLastCellNum() ; c < cn ; c++) {
        	
            Cell cell = row.getCell(c, Row.RETURN_BLANK_AS_NULL);
            if ( ! firstCell ) sb.append(delimiter); //out.print(','); 
            if ( cell != null ) {
                if ( fe != null ) cell = fe.evaluateInCell(cell);
                String value = formatter.formatCellValue(cell);
                if ( cell.getCellType() == Cell.CELL_TYPE_FORMULA ) {
                    value = "=" + value;
                }
              
                switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    sb.append(encodeValue(cell.getStringCellValue(),delimiter));
                    //System.out.print(encodeValue(cell.getStringCellValue()));
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                	
                    	cell.setCellType(Cell.CELL_TYPE_STRING);
                       //System.out.print(cell.getStringCellValue());
                   
                    sb.append(encodeValue(cell.getStringCellValue(),delimiter));
                    //System.out.print(encodeValue(Double.toString(cell.getNumericCellValue())));
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                   sb.append(encodeValue(Boolean.toString(cell.getBooleanCellValue()),delimiter));
                    //System.out.print(encodeValue(Boolean.toString(cell.getBooleanCellValue())));
                    break;
                    
                default:
                }
                
               // System.out.println(c+","+row.getLastCellNum());
                //out.print(encodeValue(value));
               // System.out.print(encodeValue(value)); 
                if(numCols< numCols_F && c==(cn-1)){
                	for(int i=0;i<col_missing;i++){
                		sb.append(delimiter);
                		
                	}
                	
                }
            }
            firstCell = false;
            
        }
        System.out.println(sb.toString());
        
        //System.out.println();
        
        fis.close();
    }

}
}
