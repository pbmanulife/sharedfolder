package com.manulife.edl.hive.udf;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * In Hive, do the following:
 * 
 * ADD JAR hdfs://azcedlmstd001.mfcgd.com:8020/user/wieneed/UDF/HiveUDF.jar; (or wherever in HDFS this jarfile is stored)
 * CREATE TEMPORARY FUNCTION BoolToStr AS 'com.manulife.edl.hive.udf.BoolToStr';  (this creates a temporary function that only works for the duration of the session)
 * Then, SELECT BoolToStr(x);
 * 
 * or
 *
 * DROP FUNCTION inv_curated.BoolToStr;
 * CREATE FUNCTION inv_curated.BoolToStr AS 'com.manulife.edl.hive.udf.BoolToStr' USING JAR 'hdfs://azcedlmstd001.mfcgd.com:8020/user/inv/curation/jar/HiveUDF.jar';
 * SELECT inv_curated.BoolToStr();
 * 
 * But the last option only works within the database in which it is defined (inv_curated in the example above), meaning that SELECT BoolToStr(x) will not work.
 * The only alternative is to send the jarfile to the sysadmin and ask him to deploy the jarfile to the Hive CLASSPATH.
 * 
 * @author Edward Wiener
 */
@Description(name = "BoolToStr", value = "Returns string representation of boolean -- Y/N")
public class BoolToStr extends UDF {
	
	private final static String YES = "Y";
	private final static String NO = "N";

	public String evaluate(Object o) {
		if (o == null)
		  return null;

		if (o instanceof Boolean)
			return (((Boolean) o).booleanValue() == false) ? NO : YES;
		else if (o instanceof String) {
			String str = ((String) o).trim().toLowerCase();
			return (str.equals("y") || str.equals("yes") || str.equals("true")) ? YES : NO;
		} else if (o instanceof Integer)
			return (((Integer) o).intValue() == 1) ? YES : NO;
		else if (o instanceof Long)
			return (((Long) o).longValue() == 1) ? YES : NO;

		return NO;

  }
}