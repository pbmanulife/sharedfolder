package com.manulife.edl.hive.udf;

import java.util.UUID;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.udf.UDFType;

/**
 * In Hive, do the following:
 * 
 * ADD JAR hdfs://azcedlmstd001.mfcgd.com:8020/user/wieneed/UDF/HiveUDF.jar; (or wherever in HDFS this jarfile is stored)
 * CREATE TEMPORARY FUNCTION Guid AS 'com.manulife.edl.hive.udf.Guid';  (this creates a temporary function that only works for the duration of the session)
 * Then, SELECT Guid(); returns the GUID
 * 
 * or
 *
 * DROP FUNCTION inv_curated.Guid;
 * CREATE FUNCTION inv_curated.Guid AS 'com.manulife.edl.hive.udf.Guid' USING JAR 'hdfs://azcedlmstd001.mfcgd.com:8020/user/inv/curation/jar/HiveUDF.jar';
 * SELECT inv_curated.Guid();
 * 
 * But the last option only works within the database in which it is defined (inv_curated in the example above), meaning that SELECT Guid() will not work.
 * The only alternative is to send the jarfile to the sysadmin and ask him to deploy the jarfile to the Hive CLASSPATH.
 * 
 * @author Edward Wiener
 */
@Description(name = "Guid", value = "Returns GUID")
@UDFType(deterministic = false)
public class Guid extends UDF {
	
  public String evaluate() {

	  UUID uuid = UUID.randomUUID();
      return uuid.toString();  
  }
}