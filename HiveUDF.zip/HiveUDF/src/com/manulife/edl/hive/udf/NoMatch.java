package com.manulife.edl.hive.udf;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * In Hive, do the following:
 * 
 * ADD JAR hdfs://azcedlmstd001.mfcgd.com:8020/user/nocerro/udf/HiveUDFjar; (or wherever in HDFS this jarfile is stored)
 * CREATE TEMPORARY FUNCTION NoMatch AS 'com.manulife.edl.hive.udf.NoMatch';  (this creates a temporary function that only works for the duration of the session)
 * Then, SELECT NoMatch(); returns the result
 * 
 * or
 *
 * DROP FUNCTION inv_curated.NoMatch;
 * CREATE FUNCTION inv_curated.NoMatch AS 'com.manulife.edl.hive.udf.NoMatch' USING JAR 'hdfs://azcedlmstd001.mfcgd.com:8020/user/inv/curation/jar/HiveUDF.jar';
 * SELECT inv_curated.NoMatch('TEST', 'NOTEST);
 * 
 * But the last option only works within the database in which it is defined (inv_curated in the example above), meaning that SELECT NoMatch() will not work.
 * The only alternative is to send the jarfile to the sysadmin and ask him to deploy the jarfile to the Hive CLASSPATH.
 * 
 * @author Rob Nocera
 */
@Description(name = "NoMatch", value = "Returns true if the two provided values do not match")
public class NoMatch extends UDF {
	
  public boolean evaluate(Object a, Object b) {

	  boolean result = false;

	  if (a == null && b == null)
		  result = false;
	  else if (a == null && b != null)
		  result = true;
	  else if (a != null && b == null)
		  result = true;
	  else if (!a.equals(b))
		  result = true;

      return result;  
  }
}