package com.manulife.edl.bpl;

import java.util.ArrayDeque;
import java.util.Deque;

public class ParentChildStack{

	private static class StackElement {
		private String uuid;
	    private String xmlRepeatingElement;
	    private int level;

	    StackElement(String uuid, String xmlRepeatingElement, int level) {
	    	this.uuid = uuid;
	    	this.xmlRepeatingElement = xmlRepeatingElement;
	    	this.level = level;
	    }

	    public String getUuid() {
	    	return this.uuid;
	    }

	    public String getXmlRepeatingElement() {
	    	return this.xmlRepeatingElement;
	    }

	    public int getLevel() {
	    	return this.level;
	    }

	    @Override
	    public String toString() {
	    	return xmlRepeatingElement + " --> " + uuid + " --> " + level;
	    }
	}

	private Deque<StackElement> stack;

	ParentChildStack() {
		this.stack = new ArrayDeque<>();
	}

	public void push(String uuid, String xmlRepeatingElement, int level) {
		this.stack.push(new StackElement(uuid, xmlRepeatingElement, level));
	}

	public void pop() {
		this.stack.pop();
	}

	public String getTopUuid() {
		if (stack == null || stack.peek() == null)
			return null;

		return stack.peek().getUuid();
	}

	public String getTopRepeatingElement() {
		if (stack == null || stack.peek() == null)
			return null;

		return stack.peek().getXmlRepeatingElement();
	}

	public int getTopRepeatingElementLevel() {
		if (stack == null || stack.peek() == null)
			return 0;

		return stack.peek().getLevel();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (StackElement se : this.stack)
			sb.append(se).append('\n');

		return sb.toString();
			
	}
}