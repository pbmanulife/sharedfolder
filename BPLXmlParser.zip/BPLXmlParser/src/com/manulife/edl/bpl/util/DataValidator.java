/**
* The following class determines whether the data in an XML element constitutes a valid INT, BIGINT, DECIMAL, BOOLEAN, or DATE.
*
* @author  Edward Wiener
* @company NEOS LLC
* @version 1.1 
*/
package com.manulife.edl.bpl.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.manulife.edl.bpl.hive.HiveColumn;

public class DataValidator {

	public static final String DATA_TYPE_MISMATCH = "Data Type Mismatch";
	public static final String CORRUPT_FILE = "Corrupt File";
	public static final String INVALID_METADATA = "Invalid Metadata";
	public static final String UNKNOWN_ERROR = "Unknown Error";

	public static void ValidateXmlValueVsType(String value, HiveColumn hc) throws BPLXmlException {
		if (hc == null)
			return;

		String dataType = hc.getType().trim().toLowerCase();

		if (dataType.equals("int")) {
			try {
				Integer.parseInt(value);
			} catch (NumberFormatException nfe) {
				throw new BPLXmlException(nfe.getMessage());
			}
		} else if (dataType.equals("bigint")) {
			try {
				Long.parseLong(value);
			} catch (NumberFormatException nfe) {
				throw new BPLXmlException(nfe.getMessage());
			}
		} else if (dataType.startsWith("decimal")) {
			try {
				Double.parseDouble(value);
			} catch (NumberFormatException nfe) {
				throw new BPLXmlException(nfe.getMessage());
			}
		} else if (dataType.startsWith("boolean")) {
			if (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false"))
				throw new BPLXmlException();
		} else if (dataType.equals("date")) {
			try {
				DateFormat df = new SimpleDateFormat(DateUtils.DATE_FORMAT);
				df.parse(value);
			} catch (java.text.ParseException pe) {
				throw new BPLXmlException(pe.getMessage());
			}
		}
	}
}
