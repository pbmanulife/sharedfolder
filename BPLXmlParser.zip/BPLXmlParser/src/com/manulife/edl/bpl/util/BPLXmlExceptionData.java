/**
* Class used to return information from an XML parsing exception.
*
* @author  Edward Wiener
* @company NEOS LLC
* @version 1.1 
*/
package com.manulife.edl.bpl.util;

public class BPLXmlExceptionData {
	
	private String errorType;
	private String value;
	private String dataType;
	private String xPath;
	private int row;

	public BPLXmlExceptionData() {}
	
	public BPLXmlExceptionData(String errorType, String value, String dataType, String xPath, int row) {
		this.errorType = errorType;
		this.value = value;
		this.dataType = dataType;
		this.xPath = xPath;
		this.row = row;
	}

	@Override
	public String toString() {
		return "ERROR: " + this.errorType + " when parsing " + this.value + " as " + this.dataType + " in " + this.xPath + " row " + this.row;
	}
}
