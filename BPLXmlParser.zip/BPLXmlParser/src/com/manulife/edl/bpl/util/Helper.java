/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl.util;

public class Helper {

	public static String getJarVersion() {
		return Helper.class.getPackage().getImplementationVersion();
	}

	public static String getJarName() {
		return Helper.class.getPackage().getImplementationTitle();
	}
}
