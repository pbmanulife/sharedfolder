/**
* This is a custom exception class for BPL parsing.
*
* @author  Edward Wiener
* @company NEOS LLC
* @version 1.1 
*/
package com.manulife.edl.bpl.util;

public class BPLXmlException extends Exception {

	private static final long serialVersionUID = 1997753363232807009L;

    public BPLXmlException() {}

    public BPLXmlException(BPLXmlExceptionData ed) {
    	super(ed.toString());
    }
    
    public BPLXmlException(String message) {
    	super(message);
    }
}
