/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class DateUtils {

	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String DATETIME_FORMAT_ISO = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String PUBLICATION_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ssX";
	public static final String PUBLICATION_TIME_FORMAT_AABOR28 = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSXXX";
	public static final String NIFI_PROCESS_TIMESTAMP_FORMAT = "yyyyMMdd_HHmmss";

	public static String getStringFromTimestamp(Date dt) {
		DateFormat df = new SimpleDateFormat(DATETIME_FORMAT);
		String dateStr = df.format(dt);

		return dateStr;
	}

	public static String getStringFromTimestampUTC(Date dt) {
		DateFormat df = new SimpleDateFormat(DATETIME_FORMAT);
		df.setTimeZone(TimeZone.getTimeZone("UTC"));
		String dateStr = df.format(dt);

		return dateStr;
	}

	public static String getStringFromDate(Date dt) {
		DateFormat df = new SimpleDateFormat(DATE_FORMAT);
		String dateStr = df.format(dt);

		return dateStr;
	}

	public static Date getBusinessDateFromString(String dtStr) throws BPLXmlException {
		return parseDateString(dtStr, DATE_FORMAT);
	}

	public static Date getPublicationTimeFromString(String dtStr) throws BPLXmlException {
		try {
			return parseDateString(dtStr, PUBLICATION_TIME_FORMAT);
		} catch (BPLXmlException bpe) {
			return parseDateString(dtStr, PUBLICATION_TIME_FORMAT_AABOR28);
		}
	}

	public static Date getProcessTimestamp(String dtStr) throws BPLXmlException {
		return parseDateString(dtStr, NIFI_PROCESS_TIMESTAMP_FORMAT);
	}

	private static Date parseDateString(String dtStr, String format) throws BPLXmlException {
		if (format == null)
			return new Date();

		try {
			DateFormat df = new SimpleDateFormat(format);
			return df.parse(dtStr);
		} catch (IllegalArgumentException | ParseException pe) {
			throw new BPLXmlException(pe.getMessage());
		}
	}
}
