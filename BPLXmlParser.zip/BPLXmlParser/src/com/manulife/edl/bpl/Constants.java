package com.manulife.edl.bpl;

public class Constants {

	public static final String PROCESS_TIMESTAMP = "process_timestamp";
	public static final String SOURCE_FILE = "source_file";
	public static final int MAX_HIVE_SCALE = 38;
	public static final boolean IS_FIELD_ENCLOSED_IN_QUOTES = false;

	public static final char DEFAULT_CSV_DELIMITER = '\u0001';
	public static final String DEFAULT_CSV_DELIMITER_TEXT = "\\001";
	public static final String DEFAULT_NULL_STRING = "\\N";
	//public static final String DEFAULT_SERDE = "org.apache.hadoop.hive.serde2.OpenCSVSerde";
}
