/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.xml.sax.SAXException;

import com.manulife.edl.bpl.hive.HiveColumn;
import com.manulife.edl.bpl.util.BPLXmlException;
import com.manulife.edl.bpl.util.BPLXmlExceptionData;
import com.manulife.edl.bpl.util.DataValidator;
import com.manulife.edl.bpl.util.DateUtils;
import com.manulife.edl.bpl.util.Helper;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public class XmlParser {

	/**
	 * java -cp BPLXmlParser-1.3.jar com.manulife.edl.bpl.XmlParser -c ..\data\PriceMaster_fields_path.csv -x ..\data\Price-Payload.xml -p Publication/Payload > Price-Payload.csv
	 *
	 * OR
	 * 
	 * java -Xmx4g -cp BPLXmlParser-1.3.jar com.manulife.edl.bpl.XmlParser -c ..\data\PriceMaster_fields_path.csv -x ..\data\Price-Payload.xml -p Publication/Payload > Price-Payload.csv
	 *
	 * depending on the size of the XML payload, more Java heap space may be necessary.
	 */

	private static final String CSV_SEPARATOR = "^^^^^^^^^^CSV";
	private static final String XML_SEPARATOR = "^^^^^^^^^^XML";
	private static final String DELIM = "\\|";
	private static final String XML_PAYLOAD_PREFIX = "Publication/Payload";

    public static PathData pd;
    public static String topLevelXpath;

	public static PathData parseCsvFile(String csvFile, boolean isStdin) {
		BufferedReader br = null;
		Map<String, HiveColumn> xpathMap = new HashMap<>();

		try {
			//
			// If we are getting the CSV via STDIN, then get it out of the csvFile variable.
			// Otherwise, this variable contains a path to the CSV on the local file system.
			//
			if (isStdin) {
				InputStream is = new ByteArrayInputStream(csvFile.getBytes());
				br = new BufferedReader(new InputStreamReader(is));
			} else
				br = new BufferedReader(new FileReader(csvFile));

			String line = br.readLine();
			while (line != null) {
				if (line.trim().length() > 0) {
					String[] ary = line.split(DELIM);
					//
					// Sample: BPL_PriceMaster,Price_Custom_CustomPrice_ML_PRICE,decimal,Price/Custom/CustomPrice/ML_PRICE,3,false,
					//
					String tableName = ary[0];
					String columnName = ary[1];
					String dataType = ary[2];
					String xpath = ary[3];
					String columnNumberStr = ary[4];
					String isGuidStr = ary[5];
					String childTableName = "";
					if (ary.length == 7)
						childTableName = ary[6];

					boolean isGuid = false;
					try {
						isGuid = Boolean.parseBoolean(isGuidStr);
					} catch (NumberFormatException ex) {}
					int columnNumber = 0;
					try {
						columnNumber = Integer.parseInt(columnNumberStr);
					} catch (NumberFormatException ex) {}

					HiveColumn hc = new HiveColumn(tableName, columnName, dataType, xpath, columnNumber,
							isGuid, childTableName);
					xpathMap.put(xpath, hc);
				}

				line = br.readLine();
			}
		} catch (IOException ie) {
			ie.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException ie) {
					ie.printStackTrace();
				}
			}
		}

		PathData pd = new PathData();
		pd.setXpathMap(xpathMap);
		return pd;
	}
	
	public static boolean hasChildElements(Element el) {
	    NodeList children = el.getChildNodes();
	    for (int i = 0; i < children.getLength(); i++) {
	        if (children.item(i).getNodeType() == Node.ELEMENT_NODE) 
	            return true;
	    }
	    return false;
	}
	
	public static void recurseXml(CSVFiles csvFiles, String tableName, int rowCounter, Node node, String path,
			ParentChildStack parentChildStack, int level, boolean isEmitUniqueXmlPaths) throws BPLXmlException {
		//
		// Recurse through each XML element node. When we reach a leaf node, i.e. a node with no children,
		// we get its value and add it to the CSV line represented by the csvRow String array.
		//
		//System.out.println(path);

		boolean isChildTable = false;

		if (node.getNodeType() == Node.ELEMENT_NODE && hasChildElements((Element) node)) {
			HiveColumn hc = pd.getHiveColumnFromXPath(path);
			if (hc != null && hc.getIsGuid()) {
				//System.out.println(path + " is a GUID");
				//System.out.println("Current level = " + level);
				//System.out.println("Top stack Repeating element: " + parentChildStack.getTopRepeatingElement());
				//System.out.println(path + " --> repeating element");
				//System.out.println("XPath = " + hc.getXpath());
				//System.out.println("Column number = " + hc.getColumnNumber());
				//System.out.println("parentChildStack");
				//System.out.println("----------------");
				//System.out.println(parentChildStack);
				//
				// We've hit a repeating element. We need to add a UUID to the parent table
				//
				CSVFile csvFile = csvFiles.get(tableName);
		    	if (csvFile == null) {
		    		csvFile = csvFiles.buildNewCSVFile();
		    		csvFiles.put(tableName,  csvFile);
		    	}
				//
				// Get current row values
				//
		    	Map<Integer, String> rowMap = csvFile.get(rowCounter);
		    	if (rowMap == null) {
		    		rowMap = new HashMap<>();
		    		csvFile.add(rowCounter, rowMap);
		    		//csvFiles.put(tableName,  csvFile);
		    	}
		    	//
		    	// Create a UUID and add it to the current (parent) table
		    	//
	    		while (level < parentChildStack.getTopRepeatingElementLevel())
	    			parentChildStack.pop();

	    		//System.out.println("node.getNodeName() = " + node.getNodeName());
	    		//System.out.println("parentChildStack.getTopRepeatingElement() = " + parentChildStack.getTopRepeatingElement());
		    	if (!removeQName(node.getNodeName()).equalsIgnoreCase(parentChildStack.getTopRepeatingElement())) {
		    		//System.out.println("current node name: " + node.getNodeName());
		    		//System.out.println("top repeating element on parent child stack: " + parentChildStack.getTopRepeatingElement());
		    		//System.out.println("Pushing " + node.getNodeName() + " onto the parentChildStack");;

		    		parentChildStack.push(UUID.randomUUID().toString(), removeQName(node.getNodeName()), level);
		    	}

		    	rowMap.put(hc.getColumnNumber(), parentChildStack.getTopUuid());
		    	
				isChildTable = true;
				tableName = hc.getChildTable();
			}
		}

		if (node.getNodeType() == Node.ELEMENT_NODE && !hasChildElements((Element) node)) {
			String value = node.getTextContent().trim().replace('\n', ' ');
			HiveColumn hiveColumn = pd.getHiveColumnFromXPath(path);
			int index = pd.getOrderNoFromXPath(hiveColumn);

			try {
				DataValidator.ValidateXmlValueVsType(value, hiveColumn);
			} catch (BPLXmlException be) {
				throw new BPLXmlException(new BPLXmlExceptionData(DataValidator.DATA_TYPE_MISMATCH, value, hiveColumn.getType(), path, rowCounter+1));
			}
	    	//System.out.println(path + " --> " + value + " --> " + index);
	    	
	    	if (!csvFiles.containsKey(tableName)) {
	    		//System.out.println("csvFiles does not contain key " + tableName);
	    		csvFiles.put(tableName, csvFiles.buildNewCSVFile());
	    	}
	    	//
	    	// Get CSV file for current table
	    	//
	    	CSVFile csvFile = csvFiles.get(tableName);
	    	if (csvFile == null) {
	    		csvFile = csvFiles.buildNewCSVFile();
	    		csvFiles.put(tableName,  csvFile);
	    	}
	    	//
	    	// Get current row values
	    	//
	    	Map<Integer, String> rowMap = csvFile.get(rowCounter);
	    	if (rowMap == null) {
	    		rowMap = new HashMap<>();
	    		csvFile.add(rowCounter, rowMap);
	    		//csvFiles.put(tableName,  csvFile);
	    	}
	    	if (index >= 0) {
	    		//System.out.println("Adding value=" + value + " at index=" + index);
	    		rowMap.put(index, value);
	    	}
	    	//
	    	// Check if null
	    	//
	    	//if (csvFile.get(rowCounter) == null) {
	    	//	System.out.println("rowCounter: " + rowCounter);
	    	//	csvFile.add(rowCounter, rowMap);
	    	//}	
		} else {
	    	NodeList nodeList = node.getChildNodes();
	    	//
	    	// Get row counter for current table (only used for child tables).
	    	//
	    	CSVFile csvFile = csvFiles.get(tableName);
	    	int childRowCounter = (csvFile == null ? 0 : csvFile.getSize());

	    	for (int i = 0; i < nodeList.getLength(); i++) {
	    		Node currentNode = nodeList.item(i);
	    		if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
	    			if (isChildTable) {
	    		    	//
	    				// Set the first (0th) field of the child table to the current value of the UUID
	    		    	//
	    		    	csvFile = csvFiles.get(tableName);
	    		    	if (csvFile == null) {
	    		    		csvFile = csvFiles.buildNewCSVFile();
	    		    		csvFiles.put(tableName, csvFile);
	    		    	}
	    		    	//
	    		    	// Get current row values
	    		    	//
	    		    	Map<Integer, String> rowMap = csvFile.get(childRowCounter);
	    		    	if (rowMap == null) {
	    		    		rowMap = new HashMap<>();
	    		    		csvFile.add(childRowCounter, rowMap);
	    		    		//csvFiles.put(tableName, csvFile);
	    		    	}

	    		    	if (!rowMap.containsKey(0) || rowMap.get(0) == null)
	    		    		rowMap.put(0, parentChildStack.getTopUuid());

	    				recurseXml(csvFiles, tableName, childRowCounter, currentNode,
	    						path + "/" + removeQName(currentNode.getNodeName()), parentChildStack,
	    							level + 1, isEmitUniqueXmlPaths);
	    			} else
	    				recurseXml(csvFiles, tableName, rowCounter, currentNode,
	    						path + "/" + removeQName(currentNode.getNodeName()),
	    							parentChildStack, level + 1, isEmitUniqueXmlPaths);
	    		}
	    	}
	    }
	}

	private static Date getBusinessDate(Document doc) {
		NodeList nodes = doc.getElementsByTagName("Payload");
		Element element = (Element) nodes.item(0);

		if (element == null)
			return null;

		String businessDate = element.getAttribute("businessDate");

		try {
			return DateUtils.getBusinessDateFromString(businessDate);
		} catch (BPLXmlException be) {
			System.out.println("ERROR: " + DataValidator.DATA_TYPE_MISMATCH + " when parsing parse business date: " + businessDate);
			System.exit(-1);
		}

		return null;
	}
	
	private static Date getPublicationTime(Document doc) {
		NodeList nodes = doc.getElementsByTagName("Publication");
		Element element = (Element) nodes.item(0);
		if (element == null)
			return null;

		String publicationTime = element.getAttribute("timeStamp");

		try {
			return DateUtils.getPublicationTimeFromString(publicationTime);
		} catch (BPLXmlException be) {
			System.out.println("ERROR: " + DataValidator.DATA_TYPE_MISMATCH + " when parsing publication time: " + publicationTime);
			System.exit(-1);
		}

		return null;
	}

	private static String getNextChildElement(Document xmlDocument, XPath xpath, String xpathExpression) {
		try {
			NodeList nodeList = (NodeList) xpath.compile(xpathExpression).evaluate(xmlDocument, XPathConstants.NODESET);
			if (nodeList == null || nodeList.getLength() == 0)
				return null;

			Node n = nodeList.item(0);
			if (n.getFirstChild() != null && n.getFirstChild().getNodeType() == Node.ELEMENT_NODE)
				return n.getFirstChild().getNodeName();
			else {
			    NodeList children = n.getChildNodes();
			    for (int i = 0; i < children.getLength(); i++) {
			        if (children.item(i).getNodeType() == Node.ELEMENT_NODE) 
			            return children.item(i).getNodeName();
			    }

			}
		} catch (XPathExpressionException xpe) {
			xpe.printStackTrace();
		}

		return null;
	}

	private static String removeQName(String nodeName) {
		String[] ary = nodeName.split(":");
		if (ary.length == 2)
			return ary[1];

		return nodeName;
	}

	public static void main(String... args) {
		String csvFile = "";
		char delimiter = Constants.DEFAULT_CSV_DELIMITER;
		String nullString = Constants.DEFAULT_NULL_STRING;
		String xmlPrefix = "";
		String xmlPayloadFile = "";
		String sourceFileName = "";
		String xmlTopLevelRepeatingElement = "";
		String zipFilePath = null;
		Date processTimestamp = null;
		boolean isEmitUniqueXmlPaths = false;
		boolean isStdinXml = false;
		boolean isStdinCsv = false;
		boolean isFieldEnclosedInQuotes = Constants.IS_FIELD_ENCLOSED_IN_QUOTES;;
		boolean isZipfile = false;
		boolean isRemoveBplFields = false;
		boolean isRepeatingElementUserProvided = false;

		Options opt = new Options();
		opt.addOption("c", "csv", true, "Path of CSV fields file");
		opt.addOption("d", "delimiter", true, "Delimiter");
		opt.addOption("n", "null", true, "NULL string representation in CSV file");
		opt.addOption("p", "prefix", true, "XML prefix");
		opt.addOption("q", "quotes", false, "Enclose strings in quotes");
		opt.addOption("r", "repeating", true, "Top-level repeating element");
		opt.addOption("s", "source", true, "XML payload filename (used only when -x option is ommitted)");
		opt.addOption("t", "timestamp", true, "Process timestamp");
		opt.addOption("u", "unique", false, "Emit unique XML elements (not XPaths) as Hive columns");
		opt.addOption("x", "xml", true, "Path of XML payload file");
		opt.addOption("z", "zipfile", true, "Emit zipped archive of CSV files");
		opt.addOption("w", "nobpl", false, "Remove BPL fields (source_file, publication_time, business_date)");
		opt.addOption("h", "help", false, "Print help");

		try {
			CommandLineParser parser = new DefaultParser();
			CommandLine cl = parser.parse(opt, args);

			if (cl.hasOption("h")) {
				HelpFormatter help = new HelpFormatter();
				help.printHelp("java -cp " + Helper.getJarName() + "-" + Helper.getJarVersion() + ".jar " +
						XmlParser.class.getName() + " [options]", opt);
				System.exit(-1);
			}

			if (cl.hasOption("csv"))
				csvFile = cl.getOptionValue("csv");
			else
				isStdinCsv = true;

			if (cl.hasOption("delimiter")) {
				String delimString = cl.getOptionValue("delimiter");
				if (delimString.equals("\\001"))
					delimiter = 0x01;
				else
					delimiter = delimString.charAt(0);
			} else
				delimiter = Constants.DEFAULT_CSV_DELIMITER;

			
			if (cl.hasOption("quotes"))
				isFieldEnclosedInQuotes = true;
			else
				isFieldEnclosedInQuotes = Constants.IS_FIELD_ENCLOSED_IN_QUOTES;

			if (cl.hasOption("null"))
				nullString = cl.getOptionValue("null");
			else
				nullString = Constants.DEFAULT_NULL_STRING;
			
			if (cl.hasOption("xml"))
				xmlPayloadFile = cl.getOptionValue("xml");
			else
				isStdinXml = true;

			if (cl.hasOption("source"))
				sourceFileName = cl.getOptionValue("source");
			else if (!isStdinXml) {
				String[] windowsPathAry = xmlPayloadFile.split("\\\\");
				String[] linuxPathAry = xmlPayloadFile.split("/");
				//
				// Check whether the path was given in Unix or Windows format and extract the filename from the path
				//
				if (windowsPathAry.length == 1 && linuxPathAry.length == 1)
					sourceFileName = xmlPayloadFile;
				else if (windowsPathAry.length > linuxPathAry.length)
					sourceFileName = windowsPathAry[windowsPathAry.length - 1];
				else
					sourceFileName = linuxPathAry[linuxPathAry.length - 1];
			}

			if (cl.hasOption("timestamp")) {
				try {
					processTimestamp = DateUtils.getProcessTimestamp(cl.getOptionValue("timestamp"));
				} catch (BPLXmlException be) {
					System.out.println("ERROR: " + DataValidator.DATA_TYPE_MISMATCH + " when parsing processTimestamp: " + cl.getOptionValue("timestamp"));
					System.exit(-1);
				}
			}

			if (cl.hasOption("zipfile")) {
				isZipfile = true;
				zipFilePath = cl.getOptionValue("zipfile");
			}

			if (cl.hasOption("prefix"))
				xmlPrefix = cl.getOptionValue("prefix");
			else
				xmlPrefix = XML_PAYLOAD_PREFIX;

			if (cl.hasOption("repeating")) {
				isRepeatingElementUserProvided = true;
				xmlTopLevelRepeatingElement = cl.getOptionValue("repeating");
			}

			if (cl.hasOption("nobpl"))
				isRemoveBplFields = true;
			/*
			else {
				System.out.println("ERROR: -r switch specifying name of top-level XML repeating element is required");
				System.exit(-1);
			}
			*/

			if (cl.hasOption("unique"))
				isEmitUniqueXmlPaths = true;
		} catch (ParseException pe) {
			pe.printStackTrace();
		}
		//
		// Start parsing
		//
		Document xmlDocument = null;
		//
		// Set up DOM objects + make XML parser namespace-aware
		//
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		if (isRepeatingElementUserProvided)
			builderFactory.setNamespaceAware(true);
		DocumentBuilder builder = null;
		try {
			builder = builderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();  
		}
		//
		// Check whether XML data is arriving via STDIN
		//
		StringBuilder sbCsv = new StringBuilder();
		StringBuilder sbXml = new StringBuilder();

		if (isStdinXml) {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			String s;
			boolean isXml = false;

			try {
				while ((s = in.readLine()) != null) {
					s = s.trim();
					if (s.length() == 0)
						continue;
					if (isStdinCsv) {
						if (s.toUpperCase().startsWith(CSV_SEPARATOR)) {
							isXml = false;
							continue;
						} else if (s.toUpperCase().startsWith(XML_SEPARATOR)) {
							isXml = true;
							continue;
						}
					} else
						isXml = true;

					if (isXml)
						sbXml.append(s).append('\n');
					else
						sbCsv.append(s).append('\n');
				}
			} catch (IOException ie) {
				ie.printStackTrace();
			} finally {
				try {
					in.close();
				} catch (IOException ie) {
					ie.printStackTrace();
				}
			}
			//
			// Read XML payload from string into document object
			//
			try {
				InputStream is = new ByteArrayInputStream(sbXml.toString().getBytes());
				xmlDocument = builder.parse(is);
			} catch (SAXException | IOException e) {
				System.out.println("ERROR: " + DataValidator.CORRUPT_FILE + "\t" + e.toString());
				System.exit(-1);
			}
		} else {
			//
			// Read XML payload from local file into document object
			//
			try {
				xmlDocument = builder.parse(new FileInputStream(xmlPayloadFile));
			} catch (SAXException | IOException e) {
				System.out.println("ERROR: " + DataValidator.CORRUPT_FILE + "\t" + e.toString());
				System.exit(-1);
			}
		}
		//
		// Check whether CSV data is arriving via STDIN
		//	
		if (isStdinCsv) {
			//
			// Extract XML elements from CSV paths file into list of strings.
			//
			pd = parseCsvFile(sbCsv.toString(), isStdinCsv);
		} else {
			//
			// Extract XML elements from CSV paths file into list of strings.
			//
			pd = parseCsvFile(csvFile, isStdinCsv);
		}
		//
		// Find top-level repeating element, e.g. <EntityMaster> or <InstrumentMaster>. Each of these corresponds to a row in Hive.
		// We know that the document beings with <Publication> and <Payload> elements, so we can skip over those.
		//
		XPath xPath = XPathFactory.newInstance().newXPath();
		String masterListElement = getNextChildElement(xmlDocument, xPath, xmlPrefix);
		String topLevelRepeatingElement = getNextChildElement(xmlDocument, xPath, xmlPrefix + "/" + masterListElement);
		if ((xmlTopLevelRepeatingElement == null || xmlTopLevelRepeatingElement.length() == 0) &&
				topLevelRepeatingElement != null)
			xmlTopLevelRepeatingElement = topLevelRepeatingElement;
		//System.out.println(xmlTopLevelRepeatingElement);

		/*
		//
		// Get number of repeating rows in payload
		//
		topLevelXpath = xmlPrefix + "/" + xmlTopLevelRepeatingElement + "List";
		try {
			XPath xPath =  XPathFactory.newInstance().newXPath();
			String expression = topLevelXpath + "/" + xmlTopLevelRepeatingElement;
			System.out.println("Evaluating expression: " + expression);
			NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODESET);
			System.out.println("Number of rows: " + nodeList.getLength());
		} catch (XPathExpressionException xpe) {
			xpe.printStackTrace();
		}
		*/

		//
		// Iterate over each repeating element, e.g. <EntityMaster>...</EntityMaster>
		//
		Map<String, Integer> tableSizeMap = pd.getNumberOfFieldsByTable();

		/*
		System.out.println("Number of tables in paths csv = " + tableSizeMap.size());
		for (String s : tableSizeMap.keySet()) {
			System.out.println("Table " + s + " --> " + tableSizeMap.get(s) + " records.");
		}
		*/

		//
		// Get publication_time and business_date
		//
		Date publicationTime = getPublicationTime(xmlDocument);
		Date businessDate = getBusinessDate(xmlDocument);	
		
		/*
		try {
			int i = 0;
			for (String s : pd.getXpathMap().keySet()) {
				String expression = xmlPrefix + "/" + xmlTopLevelRepeatingElement + "List" + "/" +
						xmlTopLevelRepeatingElement + "/" + s;
				System.out.println(++i + "-->" + expression);
				NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODESET);
			}
		} catch (XPathExpressionException xpe) {
			xpe.printStackTrace();
		}
		System.exit(-1);
		*/

        NodeList nodeList = null;

        if (isRepeatingElementUserProvided)
        	nodeList = xmlDocument.getElementsByTagNameNS("*", xmlTopLevelRepeatingElement);
        else
        	nodeList = xmlDocument.getElementsByTagName(xmlTopLevelRepeatingElement);
        
        CSVFiles csvFiles = new CSVFiles(delimiter, nullString, isFieldEnclosedInQuotes);
        //
        // Recursion has to start at the parent (master) table. Check the tableSizeMap; if it has only one table
        // that table is obviously the master. Otherwise, we call a method that finds the master table by looking for all
        // the child UUID fields in the paths CSV and tracking which child tables each UUID is associated with. Any table
        // that is not referenced as a child table is the master table.
        //
        String parentTable = "";
    	if (tableSizeMap.size() == 1) {
   		 	Map.Entry<String, Integer> entry = tableSizeMap.entrySet().iterator().next();
   		 	String key = entry.getKey();
   		 	parentTable = key;
    	} else
    		parentTable = pd.getParentTable();
    	//
    	// Now recurse through the XML.
    	//
    	try {
    		for (int i = 0; i < nodeList.getLength(); i++) {
    			Node n = nodeList.item(i);
    			ParentChildStack parentChildStack = new ParentChildStack();
    			recurseXml(csvFiles, parentTable, i, n, "/" + removeQName(xmlTopLevelRepeatingElement),
    					parentChildStack, 1, isEmitUniqueXmlPaths);
    		}
    	} catch (BPLXmlException be) {
    		System.out.println(be.getMessage());
    		System.exit(-1);
    	}
        //
        // Set the number of columns in each table (we need this to allocate memory for the CSV arrays that will store data for each row of each table)
        // Also, set the publication time, business date (from the first two tags of the XML payload), the load time (which is current time)
        // and print the emit the CSV files.
        //
    	HiveColumn publicationTimeColumn = pd.getHiveColumnFromXPath("publication_time");
    	HiveColumn businessDateColumn = pd.getHiveColumnFromXPath("business_date");
        if (isRemoveBplFields == false && (publicationTimeColumn == null || businessDateColumn == null)) {
			System.out.println("ERROR: " + DataValidator.UNKNOWN_ERROR + " probably caused by invalid CSV paths file.");
			System.exit(-1);
        }

    	csvFiles.setTableWidths(tableSizeMap);
    	if (!isRemoveBplFields) {
    		csvFiles.setPublicationTime(parentTable, publicationTime, publicationTimeColumn.getColumnNumber());
    		csvFiles.setBusinessDate(parentTable, businessDate, businessDateColumn.getColumnNumber());
    	}
		csvFiles.setSourceFile(sourceFileName, pd.getIndexOfFieldByTable(Constants.SOURCE_FILE));
    	csvFiles.setProcessTimeStamp(processTimestamp == null ? new Date() : processTimestamp, pd.getIndexOfFieldByTable(Constants.PROCESS_TIMESTAMP));
    	//
    	// Output either zipfile or STDOUT
    	//
    	if (!isZipfile)
    		csvFiles.print();
    	else {
    		boolean isZipFileEmpty = csvFiles.compress(zipFilePath);
    		if (isZipFileEmpty)
    			System.out.println("EMPTY");
    	}
    	//
    	// The following approach is more elegant (overriding toString()), but it uses a lot of memory
    	//
    	//System.out.println(csvFiles);
	}
}
