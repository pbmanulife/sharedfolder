/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.cli.*;

import org.apache.ws.commons.schema.*;
import org.apache.ws.commons.schema.resolver.URIResolver;

import org.xml.sax.InputSource;

import com.manulife.edl.bpl.hive.HiveColumn;
import com.manulife.edl.bpl.hive.HiveColumnList;
import com.manulife.edl.bpl.hive.HiveDDL;
import com.manulife.edl.bpl.util.BPLXmlException;
import com.manulife.edl.bpl.util.DataValidator;
import com.manulife.edl.bpl.util.Helper;

public class GenerateHiveTables {

	/**
	 * java -cp BPLXmlParser-1.3.jar com.manulife.edl.bpl.GenerateHiveTables -x Master.xsd -d <HIVE_TYPED_DB_NAME> -r <HIVE_RAW_DB_NAME> -t <HIVE_MASTER_TABLE_NAME>
	 * 
	 * OR
	 * 
	 * java -cp BPLXmlParser-1.3.jar com.manulife.edl.bpl.GenerateHiveTables -d <HIVE_TYPED_DB_NAME> -r <HIVE_RAW_DB_NAME> -t <HIVE_MASTER_TABLE_NAME> -m <MASTER_XSD_DOC_NAME> < [merged XSD file]
	 *
	 */

	private static final String SEPARATOR = "^^^^^^^^^^SEPARATOR";
	private static final String OLD_PATHS_SEPARATOR = "^^^^^^^^^^OLD";
	private static String BASE_HDFS_LOCATION = "/user/inv/raw/certified";

	static class ResourceResolver implements URIResolver {

		private Map<String, String> xsdMap;

		ResourceResolver(Map<String, String> xsdMap) {
			this.xsdMap = xsdMap;
		}

		public InputSource resolveEntity(String targetNamespace, String schemaLocation, String baseUri) {
			try {
				InputStream stream = new ByteArrayInputStream(xsdMap.get(schemaLocation).getBytes(StandardCharsets.UTF_8));
				return new InputSource(stream);
			} catch(Exception ex) {
				ex.printStackTrace();
			}

			return null;
		}
	}

	static class XsdMapAndPaths {
		private Map<String, String> xsdMap;
		private String oldPaths;

		XsdMapAndPaths(Map<String, String> xsdMap, String oldPaths) {
			this.xsdMap = xsdMap;
			this.oldPaths = oldPaths;
		}

		Map<String, String> getXsdMap() {
			return this.xsdMap;
		}

		String getOldPaths() {
			return this.oldPaths;
		}
	}

	private static XsdMapAndPaths readStdin() throws IOException {
		Map<String,String> xsdMap = new HashMap<>();

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder xsdSb = new StringBuilder();
		StringBuilder oldPathsSb = new StringBuilder();
		StringBuilder fileName = new StringBuilder();
		String s;
		boolean isXsd = true;

		while ((s = in.readLine()) != null) {
			s = s.trim();
			if (s.length() == 0)
				continue;

			if (s.toUpperCase().startsWith(OLD_PATHS_SEPARATOR)) {
				isXsd = false;
				continue;
			}

			if (s.toUpperCase().startsWith(SEPARATOR)) {
				isXsd = true;

				if (fileName.length() != 0) {
					xsdMap.put(fileName.toString().trim(), xsdSb.toString());
					xsdSb.setLength(0);
				}
				//
				// Assume XSD filename follows SEPARATOR:
				// Strip off everything after the colon excluding spaces and hyphens
				//
				int colonIndex = s.indexOf(':');
				fileName = new StringBuilder();
				while (++colonIndex < s.length()) {
					if (s.charAt(colonIndex) != '^' && s.charAt(colonIndex) != ' ')
						fileName.append(s.charAt(colonIndex));
				}
			}

			if (!s.toUpperCase().startsWith(SEPARATOR) && !s.toUpperCase().startsWith(OLD_PATHS_SEPARATOR)) {
				if (isXsd)
					xsdSb.append(s).append('\n');
				else
					oldPathsSb.append(s).append('\n');
			}
		}

		xsdMap.put(fileName.toString().trim(), xsdSb.toString());

		return new XsdMapAndPaths(xsdMap, oldPathsSb.toString());
	}
	  
	public static void main(String[] args) {

		String delimiterText = Constants.DEFAULT_CSV_DELIMITER_TEXT;
		String xsdFilePath = "";
		String masterXsdFileName = "";
		String hiveRawDatabaseName = "";
		String hiveTypedDatabaseName = "";
		String hiveTableName = "";
		String rawPartitionFieldName = "";
		String rawPartitionFieldType = "";
		String typedPartitionFieldName = "";
		String typedPartitionFieldType = "";
		String typedClusteringFieldName = "";
		int numClusteringBuckets = 0;
		String[] excludedColumns = null;
		String hiveCurrentTimestampZone = null;
		boolean isStdin = false;
		boolean isRawTablesPartitioned = false;
		boolean isTypedTablesPartitioned = false;
		boolean isTypedTablesClustered = false;
		boolean isEmitUniqueXmlPaths = false;
		boolean isRemoveBplFields = false;
		boolean isUseHiveCurrentTimestamp = false;
		boolean isDebugMode = false;
		boolean isEmitViews = false;
		
		Options opt = new Options();
		opt.addOption("x", "xsd", true, "Path of master XSD file");
		opt.addOption("d", "db", true, "Hive typed database name");
		opt.addOption("D", "delimiter", true, "Hive typed database name");
		opt.addOption("r", "rawdb", true, "Hive raw database name");
		opt.addOption("b", "basehdfs", true, "Base HDFS location of external payload data");
		opt.addOption("s", "nobpl", false, "Remove BPL fields (source_file, publication_time, business_date)");
		opt.addOption("t", "table", true, "Hive parent table name");
		opt.addOption("m", "master", true, "Name of master XSD, e.g. InstrumentMaster.xsd. Needed when XSDs are merged and sent via STDIN.");
		opt.addOption("v", "views", false, "Generate views to cast raw data");
		opt.addOption("h", "help", false, "Print help");
		opt.addOption("debug", false, "Use debug mode");
		//
		// Current time options. Allow convertion to UTC from specified timezone
		//
		Option currentTimeOption = new Option("C", "currenttime", false, "Use Hive current_timestamp instead of user-provided time in the view definition");
		currentTimeOption.setArgs(1);
		currentTimeOption.setOptionalArg(true);
		opt.addOption(currentTimeOption);
		//
		// Allow "normalized" parsing where column names are unique irrespective of XPath, but provide for a list of exceptions
		//
		Option pUniqueOption = new Option("u", "unique", false, "Emit unique XML elements (not XPaths) as Hive columns, with optional exclusions");
		pUniqueOption.setArgs(Option.UNLIMITED_VALUES);
		pUniqueOption.setOptionalArg(true);
		opt.addOption(pUniqueOption);
		//
		// Partitioning options
		//
		Option pRawOption = new Option("p", "partitioned-raw", true, "Partition Hive external table");
		pRawOption.setArgs(2);
		opt.addOption(pRawOption);
		Option pTypedOption = new Option("P", "partitioned-typed", true, "Partition Hive typed table");
		pTypedOption.setArgs(2);
		opt.addOption(pTypedOption);
		//
		// Clustering options
		//
		Option cTypedOption = new Option("c", "cluster-typed", true, "Cluster Hive typed table");
		cTypedOption.setArgs(2);
		opt.addOption(cTypedOption);
		//
		try {
			CommandLineParser parser = new DefaultParser();
			CommandLine cl = parser.parse(opt, args);

			if (cl.hasOption("h")) {
				HelpFormatter help = new HelpFormatter();
				help.printHelp("java -cp " + Helper.getJarName() + "-" + Helper.getJarVersion() + ".jar " +
						GenerateHiveTables.class.getName() + " [options]", opt);
				System.exit(-1);
			}

			if (cl.hasOption("db"))
				hiveTypedDatabaseName = cl.getOptionValue("db");
			else {
				System.out.println("ERROR: -d switch specifying Hive typed database name is required");
				System.exit(-1);
			}

			if (cl.hasOption("delimiter"))
				delimiterText = cl.getOptionValue("delimiter");
			else
				delimiterText = Constants.DEFAULT_CSV_DELIMITER_TEXT;

			if (cl.hasOption("rawdb"))
				hiveRawDatabaseName = cl.getOptionValue("rawdb");
			else {
				System.out.println("ERROR: -r switch specifying Hive raw database name is required");
				System.exit(-1);
			}

			if (cl.hasOption("table"))
				hiveTableName = cl.getOptionValue("table");
			else {
				System.out.println("ERROR: -t switch specifying Hive table name is required");
				System.exit(-1);
			}

			if (cl.hasOption("xsd"))
				xsdFilePath = cl.getOptionValue("xsd");
			else {
				isStdin = true;

				if (cl.hasOption("master"))
					masterXsdFileName = cl.getOptionValue("master");
				else {
					System.out.println("ERROR: -m switch specifying name of master XSD file is required in STDIN mode");
					System.exit(-1);
				}
			}

			if (cl.hasOption("basehdfs"))
				BASE_HDFS_LOCATION = cl.getOptionValue("basehdfs").trim();
			//
			// If path ends with slash, drop the slash.
			//
			if (BASE_HDFS_LOCATION.charAt(BASE_HDFS_LOCATION.length() - 1) == '/')
				BASE_HDFS_LOCATION = BASE_HDFS_LOCATION.substring(0, BASE_HDFS_LOCATION.length() - 1);

			if (cl.hasOption("partitioned-raw")) {
				isRawTablesPartitioned = true;
				String[] a = cl.getOptionValues("partitioned-raw");
				rawPartitionFieldName = a[0].trim();
				rawPartitionFieldType = a[1].trim();
			}

			if (cl.hasOption("partitioned-typed")) {
				isTypedTablesPartitioned = true;
				String[] a = cl.getOptionValues("partitioned-typed");
				typedPartitionFieldName = a[0].trim();
				typedPartitionFieldType = a[1].trim();
			}

			if (cl.hasOption("cluster-typed")) {
				isTypedTablesClustered = true;
				String[] a = cl.getOptionValues("cluster-typed");
				typedClusteringFieldName = a[0].trim();
				try {
					numClusteringBuckets = Integer.parseInt(a[1].trim());
				} catch (NumberFormatException nfe) {
					System.out.println("ERROR: Invalid number of buckets in clustered table");
					System.exit(-1);
				}
			}

			if (cl.hasOption("unique")) {
				isEmitUniqueXmlPaths = true;
				excludedColumns = cl.getOptionValues("unique");
			}

			if (cl.hasOption("nobpl"))
				isRemoveBplFields = true;

			if (cl.hasOption("currenttime")) {
				isUseHiveCurrentTimestamp = true;
				String[] a = cl.getOptionValues("currenttime");
				if (a != null && a.length > 0)
					hiveCurrentTimestampZone = a[0];
			}
			
			if (cl.hasOption("views"))
				isEmitViews = true;
			
			if (cl.hasOption("debug"))
				isDebugMode = true;
		} catch (ParseException pe) {
			pe.printStackTrace();
		}

		try {
			XmlSchemaCollection schemaCol = new XmlSchemaCollection();
			XmlSchema schema = null;
			XsdMapAndPaths mapAndPaths = null;

			if (isStdin) {
				//
				// Read schemas from standard input into a Java Map where key = name of XSD and value = contents of XSD.
				//
				mapAndPaths = readStdin();
				Map<String, String> xsdDocumentsMap = mapAndPaths.getXsdMap();
				//
				// We need to know the name of the "master" XSD because it is this XSD that we must load into the schema collection. This master XSD
				// has references to the other XSDs via <xs:import> and <xs:include> tags, which our schema parser will find automatically.
				// The name of the master XSD is specified from the command line using the -m or --master switch.
				//
				schemaCol.setSchemaResolver(new ResourceResolver(xsdDocumentsMap));
				if (!xsdDocumentsMap.containsKey(masterXsdFileName)) {
					System.out.println("ERROR: " + masterXsdFileName + " was not found in the merged schema, which contains the following XSDs:");
					for (String key : xsdDocumentsMap.keySet())
						System.out.println(key);
					System.exit(-1);
				}
				InputStream is = new ByteArrayInputStream(xsdDocumentsMap.get(masterXsdFileName).getBytes(StandardCharsets.UTF_8));
				StreamSource ss = new StreamSource();
				ss.setInputStream(is);
				try {
					schema = schemaCol.read(new StreamSource(is));
				} catch (Exception ex) {
					System.out.println("ERROR: " + DataValidator.INVALID_METADATA + "\t" + ex.toString());
					System.exit(-1);
				}
			} else {
				//
				// If schemas are not coming via STDIN, load the master schema from the local file system.
				//
				InputStream is = new FileInputStream(xsdFilePath);
				try {
					schema = schemaCol.read(new StreamSource(is));
				} catch (Exception ex) {
					System.out.println("ERROR: " + DataValidator.INVALID_METADATA + "\t" + ex.toString());
					System.exit(-1);
				}
			}
			//
			// Parse XSDs
			//
			XsdParser xsdParser = new XsdParserImpl(schema, isEmitUniqueXmlPaths, excludedColumns);
			HiveDDL hDDL = null;
			try {
				hDDL = xsdParser.processXmlSchema(isRemoveBplFields);
			} catch (BPLXmlException be) {
				System.out.println("ERROR: " + DataValidator.INVALID_METADATA + "\t" + be.toString());
				System.exit(-1);
			}

			////////////////////////////////////////////////
			//                                            //
			// Check whether we received an old paths CSV //
			//                                            //
			////////////////////////////////////////////////

			String oldPaths = mapAndPaths == null ? "" : mapAndPaths.getOldPaths();
			if (oldPaths != null && oldPaths.length() > 0) {
				PathData pd = XmlParser.parseCsvFile(oldPaths, true);
				//
				// Define old and new Hive DDL data structures. These will be compared for changes.
				//
				Map<String, HiveColumnList> oldColumnMap = pd.getTableMap();
				Map<String, HiveColumnList> tempNewColumnMap = hDDL.getTables();
				Map<String, HiveColumnList> newColumnMap = new HashMap<>();

				for (String key : tempNewColumnMap.keySet())
					newColumnMap.put(key.toLowerCase(), tempNewColumnMap.get(key));

				//
				// Define data structures to hold table and column changes
				//
				Map<String, HiveColumnList> addedTablesMap = new HashMap<>();
				Map<String, HiveColumnList> addedColumnsMap = new HashMap<>();
				Map<String, HiveColumnList> changedColumnsMap = new HashMap<>();
				Set<String> changedTables = new HashSet<>();
				//
				// Iterate through new Hive DDL
				//
				for (String key : newColumnMap.keySet()) {
					String newTableName = key.equalsIgnoreCase("parent") ? hiveTableName :
						hiveTableName + "_" + key;
					//
					// Make everything lowercase
					//
					key = key.toLowerCase();
					newTableName = newTableName.toLowerCase();

					//System.out.println("key = " + key + ", newTableName = " + newTableName);
					if (!oldColumnMap.containsKey(newTableName)) {
						//
						// Table has been added
						//
						//System.out.println("Table: " + newTableName + " has been added.");

						HiveColumnList toLst = new HiveColumnList();
						HiveColumnList fromLst = newColumnMap.get(key);
						for (HiveColumn fromColumn : fromLst.getList())
							toLst.add(fromColumn);
						addedTablesMap.put(key, toLst);

						oldColumnMap.put(newTableName, newColumnMap.get(key));
					} else {
						//
						// The table is not new. Let's check the columns
						//
						HiveColumnList newColumns = newColumnMap.get(key);
						HiveColumnList oldColumns = oldColumnMap.get(newTableName);
						boolean isFound = false;

						for (HiveColumn newColumn : newColumns.getList()) {
							isFound = false;
							//System.out.println("column = " + newColumn.getName());
							for (HiveColumn oldColumn : oldColumns.getList()) {
								if (newColumn.getName().equalsIgnoreCase(oldColumn.getName())) {			
									if (!newColumn.getType().equalsIgnoreCase(oldColumn.getType())) {
										//
										// Column type has changed
										//
										/*
										System.out.println("Type of " + newColumn.getName() + " has changed from " + oldColumn.getType() +
												" to " + newColumn.getType());
										*/
										if (!changedColumnsMap.containsKey(key))
											changedColumnsMap.put(key, new HiveColumnList());
										HiveColumnList lst = changedColumnsMap.get(key);
										lst.add(newColumn);
										//
										// Update column type in old schema (this is needed to generate the raw-to-typed view
										//
										HiveColumnList oldList = oldColumnMap.get(newTableName);
										for (HiveColumn hc : oldList.getList()) {
											if (hc.getName().equalsIgnoreCase(newColumn.getName()))
												hc.setType(newColumn.getType());
										}
										changedTables.add(newTableName);

										isFound = true;
										break;
									} else {
										isFound = true;
										break;
									}
								}
							}

							if (!isFound) {
								//
								// New column added for existing table
								//
								if (!addedColumnsMap.containsKey(key))
									addedColumnsMap.put(key, new HiveColumnList());
								HiveColumnList lst = addedColumnsMap.get(key);
								lst.add(newColumn);
								//
								// Add new column to old schema (this is needed to generate the raw-to-typed view
								//
								oldColumnMap.get(newTableName).add(newColumn);
								changedTables.add(newTableName);
							}
						}
						//
						// Check for new XPaths for columns that are not new in the XSD
						//
						newColumns = newColumnMap.get(key);
						oldColumns = oldColumnMap.get(newTableName);
						for (HiveColumn newColumn : newColumns.getList()) {
							for (HiveColumn oldColumn : oldColumns.getList()) {
								if (newColumn.getName().equalsIgnoreCase(oldColumn.getName())) {
									for (String newCol : newColumn.getXpath()) {
										boolean foundPath = false;
										for (String oldCol : oldColumn.getXpath()) {
											if (newCol.equalsIgnoreCase(oldCol)) {
												foundPath = true;
												break;
											}
										}
										if (!foundPath) {
											if (isDebugMode)
												System.out.println("Adding new XPath for existing element " + newCol);
											oldColumn.getXpath().add(newCol);
										}
									}
								}
							}
						}
						//
						// Check for old XPaths that have been dropped in the new XSD
						//
						if (isDebugMode) {
							newColumns = newColumnMap.get(key);
							oldColumns = oldColumnMap.get(newTableName);
							for (HiveColumn oldColumn : oldColumns.getList()) {
								boolean foundColumn = false;
								for (HiveColumn newColumn : newColumns.getList()) {
									if (newColumn.getName().equalsIgnoreCase(oldColumn.getName())) {
										foundColumn = true;
										for (String oldCol : oldColumn.getXpath()) {
											boolean foundPath = false;
											for (String newCol : newColumn.getXpath()) {
												if (oldCol.equalsIgnoreCase(newCol)) {
													foundPath = true;
													break;
												}
											}
											if (!foundPath && isDebugMode)
												System.out.println("Dropped XPath " + oldCol);
										}
									}
								}
								if (!foundColumn && isDebugMode)
									System.out.println("Dropped column " + oldColumn.getName() + " from table " + oldColumn.getTable());
							}	
						}
					}
				}
				//
				// Emit DDL for new tables added to schema
				//
				if (addedTablesMap.size() > 0) {
					HiveDDL addedTablesDDL = new HiveDDL(addedTablesMap);

					addedTablesDDL.setDelimiterText(delimiterText);
					addedTablesDDL.setIsRawTable(true);
					addedTablesDDL.setIsRawTablePartitioned(isRawTablesPartitioned);
					addedTablesDDL.setRawPartitionFieldName(rawPartitionFieldName);
					addedTablesDDL.setRawPartitionFieldType(rawPartitionFieldType);
					addedTablesDDL.setBaseHdfsLocation(BASE_HDFS_LOCATION);
					addedTablesDDL.setHiveDB(hiveRawDatabaseName);
					addedTablesDDL.setHiveParentTable(hiveTableName);
					System.out.println(addedTablesDDL);
					//
					// Emit Hive DDL for Hive-managed inv_typed tables using the ORC storage format.
					//
					addedTablesDDL.setIsRawTable(false);
					addedTablesDDL.setIsRawTablePartitioned(false);
					addedTablesDDL.setIsTypedTablePartitioned(isTypedTablesPartitioned);
					addedTablesDDL.setIsTypedTablesClustered(isTypedTablesClustered);
					addedTablesDDL.setTypedPartitionFieldName(typedPartitionFieldName);
					addedTablesDDL.setTypedPartitionFieldType(typedPartitionFieldType);
					addedTablesDDL.setTypedClusteringFieldName(typedClusteringFieldName);
					addedTablesDDL.setTypedNumClusteringBuckets(numClusteringBuckets);	
					addedTablesDDL.setHiveDB(hiveTypedDatabaseName);
					addedTablesDDL.setHiveParentTable(hiveTableName);
					addedTablesDDL.setFileFormat("ORC");
					System.out.println(addedTablesDDL);
					//
					// Emit views which CAST each field of the String-datatyped inv_raw tables into an equivalent typed field.
					//
					if (isEmitViews) {
						addedTablesDDL.setIsRawTable(true);
						addedTablesDDL.setIsRawTablePartitioned(isRawTablesPartitioned);
						addedTablesDDL.setRawPartitionFieldName(rawPartitionFieldName);
						System.out.println(addedTablesDDL.getCastedHiveView(hiveRawDatabaseName, false,
								isUseHiveCurrentTimestamp, hiveCurrentTimestampZone, null));
					}
				}
				//
				// Emit DDL for new columns added to existing tables
				//
				if (addedColumnsMap.size() > 0) {
					//
					// Add columns to raw tables
					//
					for (String key : addedColumnsMap.keySet()) {
						HiveColumnList value = addedColumnsMap.get(key);
						System.out.println(HiveDDL.getAlterTableAddStatement(hiveRawDatabaseName,
								key.equalsIgnoreCase("parent") ? hiveTableName : hiveTableName + "_" + key, value)
								.toString());
					}
					//
					// Add columns to typed tables
					//
					for (String key : addedColumnsMap.keySet()) {
						HiveColumnList value = addedColumnsMap.get(key);
						System.out.println(HiveDDL.getAlterTableAddStatement(hiveTypedDatabaseName,
								key.equalsIgnoreCase("parent") ? hiveTableName : hiveTableName + "_" + key, value)
								.toString());
					}
					//
					// Emit casted view
					//
					if (isEmitViews) {
						HiveDDL addedColumnsDDL = new HiveDDL(oldColumnMap);
						addedColumnsDDL.setIsRawTable(true);
						addedColumnsDDL.setHiveParentTable(hiveTableName);
						addedColumnsDDL.setIsRawTablePartitioned(isRawTablesPartitioned);
						addedColumnsDDL.setRawPartitionFieldName(rawPartitionFieldName);
						System.out.println(addedColumnsDDL.getCastedHiveView(hiveRawDatabaseName, true,
								isUseHiveCurrentTimestamp, hiveCurrentTimestampZone, changedTables));
					}
				}
				//
				// Emit DDL for columns whose datatype has changed
				//
				if (changedColumnsMap.size() > 0) {
					//
					// Update columns in raw tables
					//
					for (String key : changedColumnsMap.keySet()) {
						HiveColumnList value = changedColumnsMap.get(key);
						System.out.println(HiveDDL.getAlterTableChangeStatement(hiveRawDatabaseName,
								key.equalsIgnoreCase("parent") ? hiveTableName : hiveTableName + "_" + key, value)
								.toString());
					}
					//
					// Update columns in typed tables
					//
					for (String key : changedColumnsMap.keySet()) {
						HiveColumnList value = changedColumnsMap.get(key);
						System.out.println(HiveDDL.getAlterTableChangeStatement(hiveTypedDatabaseName,
								key.equalsIgnoreCase("parent") ? hiveTableName : hiveTableName + "_" + key, value)
								.toString());
					}
					//
					// Emit casted view
					//
					if (isEmitViews) {
						HiveDDL changedColumnsDDL = new HiveDDL(oldColumnMap);
						changedColumnsDDL.setIsRawTable(true);
						changedColumnsDDL.setHiveParentTable(hiveTableName);
						changedColumnsDDL.setIsRawTablePartitioned(isRawTablesPartitioned);
						changedColumnsDDL.setRawPartitionFieldName(rawPartitionFieldName);
						System.out.println(changedColumnsDDL.getCastedHiveView(hiveRawDatabaseName, true,
								isUseHiveCurrentTimestamp, hiveCurrentTimestampZone, changedTables));
					}
				}
				//
				// Emit comma-separated paths
				//
				HiveDDL changedColumnsDDL = new HiveDDL(oldColumnMap);
				changedColumnsDDL.setHiveParentTable(hiveTableName);
				System.out.println(changedColumnsDDL.getPaths(true));
			} else {
				//
				// Emit Hive DDL for external tables (inv_raw schema)
				// These use CSVSerde and specify an HDFS location where the CSV payload files are stored.
				//
				hDDL.setDelimiterText(delimiterText);
				hDDL.setIsRawTable(true);
				hDDL.setIsRawTablePartitioned(isRawTablesPartitioned);
				hDDL.setRawPartitionFieldName(rawPartitionFieldName);
				hDDL.setRawPartitionFieldType(rawPartitionFieldType);
				hDDL.setBaseHdfsLocation(BASE_HDFS_LOCATION);
				hDDL.setHiveDB(hiveRawDatabaseName);
				hDDL.setHiveParentTable(hiveTableName);
				System.out.println(hDDL);
				//
				// Emit Hive DDL for Hive-managed inv_typed tables using the ORC storage format.
				//
				hDDL.setIsRawTable(false);
				hDDL.setIsRawTablePartitioned(false);
				hDDL.setIsTypedTablePartitioned(isTypedTablesPartitioned);
				hDDL.setIsTypedTablesClustered(isTypedTablesClustered);
				hDDL.setTypedPartitionFieldName(typedPartitionFieldName);
				hDDL.setTypedPartitionFieldType(typedPartitionFieldType);
				hDDL.setTypedClusteringFieldName(typedClusteringFieldName);
				hDDL.setTypedNumClusteringBuckets(numClusteringBuckets);	
				hDDL.setHiveDB(hiveTypedDatabaseName);
				hDDL.setHiveParentTable(hiveTableName);
				hDDL.setFileFormat("ORC");
				System.out.println(hDDL);
				//
				// Emit views which CAST each field of the String-datatyped inv_raw tables into an equivalent typed field.
				//
				if (isEmitViews) {
					hDDL.setIsRawTable(true);
					hDDL.setIsRawTablePartitioned(isRawTablesPartitioned);
					hDDL.setRawPartitionFieldName(rawPartitionFieldName);
					System.out.println(hDDL.getCastedHiveView(hiveRawDatabaseName, false,
							isUseHiveCurrentTimestamp, hiveCurrentTimestampZone, null));
				}
				//
				// Emit comma-separated paths
				//
				System.out.println(hDDL.getPaths(false));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}