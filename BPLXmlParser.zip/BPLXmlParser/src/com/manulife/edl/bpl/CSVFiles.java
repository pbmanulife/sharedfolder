/**
 * This class represents a collection of CSVFile objects, where each object holds the CSV representation of one BPL
 * Hive table in raw (string) format.
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.manulife.edl.bpl.util.DateUtils;

public class CSVFiles {

	private static final String SEPARATOR = "^^^^^^^^^^SEPARATOR";
	private Map<String, CSVFile> csvFiles;
	private Map<String, Integer> tableWidths;
	
	private char delimiter;
	private String nullString;
	private boolean isFieldEnclosedInQuotesFlag;

	CSVFiles(char delimiter, String nullString, boolean isFieldEnclosedInQuotesFlag) {
		this.csvFiles = new HashMap<>();

		this.delimiter = delimiter;
		this.nullString = nullString;
		this.isFieldEnclosedInQuotesFlag = isFieldEnclosedInQuotesFlag;
	}
	
	CSVFile buildNewCSVFile() {
		return new CSVFile(delimiter, nullString, isFieldEnclosedInQuotesFlag);
	}

	public Map<String, CSVFile> getCsvFiles() {
		return this.csvFiles;
	}

	public boolean containsKey(String key) {
		if (csvFiles == null)
			return false;
		return this.csvFiles.containsKey(key);
	}

	public CSVFile get(String key) {
		if (csvFiles == null)
			return null;
		return this.csvFiles.get(key);
	}

	public void put(String key, CSVFile value) {
		csvFiles.put(key, value);
	}

	public void setTableWidths(Map<String, Integer> tableWidths) {
		this.tableWidths = tableWidths;
	}

	public void setPublicationTime(String parentTable, Date dt, int columnIndex) {
		CSVFile csvFile = this.csvFiles.get(parentTable);
		if (csvFile != null)
			csvFile.setColumnValue(columnIndex, DateUtils.getStringFromTimestampUTC(dt));
	}

	public void setBusinessDate(String parentTable, Date dt, int columnIndex) {
		CSVFile csvFile = this.csvFiles.get(parentTable);
		if (csvFile != null)
			csvFile.setColumnValue(columnIndex, DateUtils.getStringFromDate(dt));
	}

	public void setProcessTimeStamp(Date dt, Map<String, Integer> indexOfProcessTimeStampPerTableMap) {
		//
		// Insert value of now variable (current date) into last field of each row of each table
		//
		String dateStr = DateUtils.getStringFromTimestamp(dt);
		for (String table : this.csvFiles.keySet()) {
			int columnIndex = indexOfProcessTimeStampPerTableMap.get(table);
			CSVFile csvFile = this.csvFiles.get(table);
			csvFile.setColumnValue(columnIndex, dateStr);
		}
	}

	public void setSourceFile(String sourceFile, Map<String, Integer> indexOfSourceFilePerTableMap) {
		int columnIndex = 0;
		for (String table : this.csvFiles.keySet()) {
			if (indexOfSourceFilePerTableMap != null && indexOfSourceFilePerTableMap.size() > 0) {
				columnIndex = indexOfSourceFilePerTableMap.get(table);
				CSVFile csvFile = this.csvFiles.get(table);
				csvFile.setColumnValue(columnIndex, sourceFile);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		for (String table : this.csvFiles.keySet()) {
			sb.append(SEPARATOR).append(": ").append(table).append('\n');
			CSVFile file = this.csvFiles.get(table);
			file.setNumberOfColumns(tableWidths.get(table) + 1);
			//System.out.println(file.debug());
			sb.append(file);
		}

		return sb.toString();
	}

	public void print() {
		for (String table : this.csvFiles.keySet()) {
			CSVFile file = this.csvFiles.get(table);
			file.setNumberOfColumns(tableWidths.get(table) + 1);
			System.out.println(SEPARATOR + ": " + table + "(" + file.getSize() + ")");
			System.out.print(file);
		}
	}

	public boolean compress(String zipFilePath) {
		if (this.csvFiles != null && this.csvFiles.size() > 0) {
			ZipOutputStream zos = null;
			FileOutputStream fos = null;

			try {
				fos = new FileOutputStream(zipFilePath);
				zos = new ZipOutputStream(fos);
				for (String table : this.csvFiles.keySet()) {
					CSVFile file = this.csvFiles.get(table);
					file.setNumberOfColumns(tableWidths.get(table) + 1);
					ZipEntry ze = new ZipEntry(table + ".csv" + "_" + file.getSize());
					zos.putNextEntry(ze);
					for (String s : file)
						zos.write(s.getBytes("UTF-8"));
					zos.closeEntry();
				}
			} catch (IOException ie) {
				ie.printStackTrace();
			} catch (Exception ex) {
				ex.printStackTrace();
			} finally {
				try {
					zos.close();
				} catch (IOException ie) {
					ie.printStackTrace();
				}
				try {
					fos.close();
				} catch (IOException ie) {
					ie.printStackTrace();
				}
			}

			return false;
		} else
			return true;
	}
}
