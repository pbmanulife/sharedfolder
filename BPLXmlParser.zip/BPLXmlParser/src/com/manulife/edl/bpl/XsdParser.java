/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl;

import org.apache.ws.commons.schema.XmlSchema;
import com.manulife.edl.bpl.hive.HiveDDL;
import com.manulife.edl.bpl.util.BPLXmlException;

public abstract class XsdParser {

    protected XmlSchema xmlSchema;
    protected HiveDDL hiveDDL;
    protected boolean isEmitUniqueXmlPaths;

	protected String getHiveNameFromXPath(String xpath) {
		if (xpath == null)
			return xpath;

		String retVal = xpath.replace('/', '_').replace('-', '_');
		if (retVal.charAt(0) == '_')
			retVal = retVal.substring(1);

		return retVal;		
	}

	protected String getParentElementfromXPath(String xpath) {
		if (xpath == null || xpath.trim().length() == 0)
			return null;

		String[] ary = xpath.split("/");
		if (ary == null || ary.length == 0)
			return null;

		return ary[ary.length-2];
	}

	abstract HiveDDL processXmlSchema(boolean isRemoveBplFields) throws BPLXmlException;
}
