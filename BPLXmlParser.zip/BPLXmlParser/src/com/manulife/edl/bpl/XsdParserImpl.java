/**
* The following class implements an XSD parser that emits Hive DDL.
*
* @author  Edward Wiener
* @company NEOS LLC
* @version 1.0 
*/
package com.manulife.edl.bpl;

import org.apache.ws.commons.schema.XmlSchema;
import org.apache.ws.commons.schema.XmlSchemaAnnotation;
import org.apache.ws.commons.schema.XmlSchemaAnnotationItem;
import org.apache.ws.commons.schema.XmlSchemaAttribute;
import org.apache.ws.commons.schema.XmlSchemaAttributeOrGroupRef;
import org.apache.ws.commons.schema.XmlSchemaChoice;
import org.apache.ws.commons.schema.XmlSchemaChoiceMember;
import org.apache.ws.commons.schema.XmlSchemaComplexType;
import org.apache.ws.commons.schema.XmlSchemaContent;
import org.apache.ws.commons.schema.XmlSchemaContentModel;
import org.apache.ws.commons.schema.XmlSchemaDocumentation;
import org.apache.ws.commons.schema.XmlSchemaComplexContent;
import org.apache.ws.commons.schema.XmlSchemaComplexContentExtension;
import org.apache.ws.commons.schema.XmlSchemaElement;
import org.apache.ws.commons.schema.XmlSchemaFractionDigitsFacet;
import org.apache.ws.commons.schema.XmlSchemaNumericFacet;
import org.apache.ws.commons.schema.XmlSchemaParticle;
import org.apache.ws.commons.schema.XmlSchemaSequence;
import org.apache.ws.commons.schema.XmlSchemaSequenceMember;
import org.apache.ws.commons.schema.XmlSchemaSimpleType;
import org.apache.ws.commons.schema.XmlSchemaSimpleTypeRestriction;
import org.apache.ws.commons.schema.XmlSchemaType;

import com.manulife.edl.bpl.hive.HiveDDL;
import com.manulife.edl.bpl.util.BPLXmlException;
import com.manulife.edl.bpl.hive.HiveColumn;
import com.manulife.edl.bpl.hive.HiveColumnList;

import javax.xml.namespace.QName;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class XsdParserImpl extends XsdParser {

	private Deque<String> tableStack;
	private Map<String, String> mapExcludedColumns;
	
	private boolean isEmitUniqueXmlPath(String col) {
		if (!this.isEmitUniqueXmlPaths)
			return false;

		if (this.mapExcludedColumns == null)
			return true;

		col = col.toLowerCase();
		return this.mapExcludedColumns.containsKey(col) ? false : true;
	}
	
	public XsdParserImpl(XmlSchema xmlSchema, boolean isEmitUniqueXmlPaths, String[] excludedColumns) {
		this.xmlSchema = xmlSchema;
		this.isEmitUniqueXmlPaths = isEmitUniqueXmlPaths;

		if (excludedColumns != null && excludedColumns.length > 0) {
			this.mapExcludedColumns = new HashMap<>();
			for (String s : excludedColumns)
				this.mapExcludedColumns.put(s, "");
		}

		this.hiveDDL = new HiveDDL();

		this.tableStack = new ArrayDeque<>();
		this.tableStack.push("parent");
	}

	public HiveDDL processXmlSchema(boolean isRemoveBplFields) throws BPLXmlException {
		Map<QName, XmlSchemaElement> schemaElements = this.xmlSchema.getElements();
		
		try {
			for (XmlSchemaElement element : schemaElements.values()) {
				XmlSchemaType schemaType = element.getSchemaType();
				if (schemaType instanceof XmlSchemaComplexType)
					processComplexType("", element, false);
				else if (schemaType instanceof XmlSchemaSimpleType)
					processSimpleType("", element, false);
			}
		} catch (Exception ex) {
			throw new BPLXmlException(ex.getMessage());
		}

		if (!isRemoveBplFields)
			hiveDDL.addBusinessTimestampFields();

		hiveDDL.addSourceFile();
		hiveDDL.addIngestionTimestamp();

		return hiveDDL;
	}

	private void iterateSchemaSequence(XmlSchemaParticle particle, String path) {
		if (particle instanceof XmlSchemaSequence) {
			XmlSchemaSequence schemaSequence = (XmlSchemaSequence) particle;	
			List<XmlSchemaSequenceMember> items = schemaSequence.getItems();

			for (XmlSchemaSequenceMember mem : items) {
				if (mem instanceof XmlSchemaElement) {
					XmlSchemaElement innerElement = ((XmlSchemaElement) mem);
					XmlSchemaType innerEleType = innerElement.getSchemaType();
					if (innerEleType instanceof XmlSchemaComplexType)
						processComplexType(path, innerElement, particle.getMaxOccurs() > 1);
					else if (innerEleType instanceof XmlSchemaSimpleType)
						processSimpleType(path, innerElement, particle.getMaxOccurs() > 1);
				}
			}
		} else if (particle instanceof XmlSchemaChoice) {
			XmlSchemaChoice schemaChoice = (XmlSchemaChoice) particle;
			List<XmlSchemaChoiceMember> items = schemaChoice.getItems();
			for (XmlSchemaChoiceMember mem : items) {
				if (mem instanceof XmlSchemaElement) {
					XmlSchemaElement innerElement = ((XmlSchemaElement) mem);
					XmlSchemaType innerEleType = innerElement.getSchemaType();
					if (innerEleType instanceof XmlSchemaComplexType)
						processComplexType(path, innerElement, particle.getMaxOccurs() > 1);
					else if (innerEleType instanceof XmlSchemaSimpleType)
						processSimpleType(path, innerElement, particle.getMaxOccurs() > 1);
				}
			}
		}
	}

	private String getHiveTypeFromXSDType(String xsdType) {
		if (xsdType == null)
			return "";

		switch (xsdType.toLowerCase()) {
		case "integer":
			return "bigint";
		case "datetime":
			return "timestamp";
		case "anytype":
			return "binary";
		case "token":
			return "string";
		default:
			return xsdType;
		}
	}

	private void processComplexContent(XmlSchemaContent complexContent, String path, String name) {
		XmlSchemaComplexContentExtension complexContentExtension = (XmlSchemaComplexContentExtension) complexContent;
		//
		// First, we have to find the base class
		//
		QName baseTypeName = complexContentExtension.getBaseTypeName();
		XmlSchemaType baseType = this.xmlSchema.getTypeByName(baseTypeName);
		//
		// If it is a complex type (and it should be), process each of
		// its elements in sequence.
		//
		if (baseType instanceof XmlSchemaComplexType) {
			XmlSchemaParticle particle = ((XmlSchemaComplexType) baseType).getParticle();
			if (particle != null) {
				iterateSchemaSequence(particle, path);
				if (name.equalsIgnoreCase(tableStack.peek()))
					tableStack.pop();
			} else {
				XmlSchemaContentModel contentModel = ((XmlSchemaComplexType) baseType).getContentModel();
				complexContent = ((XmlSchemaComplexContent) contentModel).getContent();
				if (complexContent != null)
					processComplexContent(complexContent, path, name);
			}
		}
		//
		// Iterate through the elements defined in the extension
		// (meaning the elements added in the sub-class
		//
		XmlSchemaParticle particle = complexContentExtension.getParticle();
		iterateSchemaSequence(particle, path);
		if (name.equalsIgnoreCase(tableStack.peek()))
			tableStack.pop();
	}

	private void processComplexType(String path, XmlSchemaElement xmlSchemaElement, boolean isUnbounded) {
		String name = xmlSchemaElement.getName();
		if (path == null || path.length() == 0)
			path = name;
		else
			path = path + "/" + name;
		// System.out.println(path);

		if (xmlSchemaElement.getMaxOccurs() > 1 || isUnbounded) {
			//System.out.println("***************************** " + path + " is UNBOUNDED in processComplexType() **********************");
			String parentTable = tableStack.peek();
			//System.out.println("parent table = " + parentTable + ", name = " + name);
			if (parentTable == null || !parentTable.equalsIgnoreCase(name)) {
				//
				// We have a new child table.
				// Push it onto the stack.
				//
				tableStack.push(name);
				//
				// Check whether child table exists
				//
				//System.out.println("Check if list " + name + " exists.");
				if (!hiveDDL.containsKey(name)) {
					//System.out.println("List " + name + " does not exist. Creating it.");
					hiveDDL.addNewList(name);
					hiveDDL.getList(name).add(new HiveColumn("uuidfk", "string", path + "/uuidfk"));
				}
				//
				// Now add a uuid to the parent table
				//
				HiveColumnList tableList = hiveDDL.getList(parentTable);
				boolean isParentTableEmpty = false;
				if (tableList == null /* || tableList.size() == 0 */) {
					tableList = hiveDDL.getList("parent");
					isParentTableEmpty = true;
				}

				if (parentTable.equalsIgnoreCase("parent") || isParentTableEmpty) {
					//System.out.println("Adding " + getHiveNameFromXPath(path) + "_uuid to parent");
					tableList.add(new HiveColumn(getHiveNameFromXPath(isEmitUniqueXmlPath(name) ? name : path) + "_uuid",
							"string", path, true, name));
				} else
					tableList.add(new HiveColumn(name + "_uuid", "string", path, true, name));

				// hiveDDL.getTables().put("parent", tableList);
			}
		}
		/*
		 * Check for the presence of <xs:complexContent> tags, used in PFM, e.g.
		 * This is inheritance in XSD
		 * 
		 * <xs:complexType name="PortfolioGroupInstitutional">
		 * 	<xs:complexContent>
		 * 		<xs:extension base="PortfolioGroupAbstract">
		 * 			<xs:sequence> <xs:element name="FISCAL" type="FISCAL" minOccurs="0"/>
		 * 				<xs:element name="PERFORMANCE" type="PERFORMANCE" minOccurs="0"/>
		 * 				<xs:element name="MAM" type="MAM" minOccurs="0"/>
		 * 				<xs:element name="ASSET_PORTFOLIO" type="ASSET_PORTFOLIO" minOccurs="1"/>
		 * 			</xs:sequence>
		 * 		</xs:extension>
		 * 	</xs:complexContent>
		 * </xs:complexType>
		 *
		 */

		List<XmlSchemaAttributeOrGroupRef> lst = ((XmlSchemaComplexType) xmlSchemaElement.getSchemaType()).getAttributes();
		if (lst != null && lst.size() > 0) {
			for (XmlSchemaAttributeOrGroupRef ref : lst) {
				if (ref instanceof XmlSchemaAttribute)
					processAttributeSimpleType(path, (XmlSchemaAttribute) ref);
			}
		}

		XmlSchemaContentModel contentModel = ((XmlSchemaComplexType) xmlSchemaElement.getSchemaType()).getContentModel();

		if (contentModel instanceof XmlSchemaComplexContent) {
			XmlSchemaContent complexContent = ((XmlSchemaComplexContent) contentModel).getContent();
			if (complexContent instanceof XmlSchemaComplexContentExtension)
				processComplexContent(complexContent, path, name);
		} else {
			XmlSchemaParticle particle = ((XmlSchemaComplexType) xmlSchemaElement.getSchemaType()).getParticle();
			iterateSchemaSequence(particle, path);
			if (name.equalsIgnoreCase(tableStack.peek())) {
				// System.out.println("name = " + name + ", tableStack.peek() = " + tableStack.peek() + ", Popping...");
				tableStack.pop();
			}
		}
	}

	private String getDocumentationBase(XmlSchemaAnnotation annotation) {
		if (annotation != null) {
			List<XmlSchemaAnnotationItem> annotationItems = annotation.getItems();
			if (annotationItems != null && annotationItems.size() > 0) {
				for (XmlSchemaAnnotationItem annotationItem : annotationItems) {
					if (annotationItem instanceof XmlSchemaDocumentation) {
						XmlSchemaDocumentation doc = (XmlSchemaDocumentation) annotationItem;
						return doc.getMarkup().item(0).getNodeValue();
					}
				}
			}
		}

		return null;
	}

	private String getDocumentation(XmlSchemaType xmlSchemaType) {
		/*
		 * Get the documentation value from the <xs:annotation> tag, which can be persisted in Hive as a column comment
		 * Example:
		 * 
		 * <xs:element name="ExDate" type="xs:dateTime" minOccurs="0">
		 * 		<xs:annotation>
		 * 			<xs:documentation>The ex-date of the dividend</xs:documentation>
		 * 		</xs:annotation>
		 * </xs:element>
		 * 
		 */

		if (xmlSchemaType == null)
			return null;

		XmlSchemaAnnotation annotation = xmlSchemaType.getAnnotation();
		return getDocumentationBase(annotation);
	}
	
	private String getDocumentation(XmlSchemaElement xmlSchemaElement) {
		/*
		 * Get the documentation value from the <xs:annotation> tag, which can be persisted in Hive as a column comment
		 * Example:
		 * 
		 * <xs:element name="ExDate" type="xs:dateTime" minOccurs="0">
		 * 		<xs:annotation>
		 * 			<xs:documentation>The ex-date of the dividend</xs:documentation>
		 * 		</xs:annotation>
		 * </xs:element>
		 * 
		 */

		if (xmlSchemaElement == null)
			return null;

		XmlSchemaAnnotation annotation = xmlSchemaElement.getAnnotation();
		return getDocumentationBase(annotation);
	}

	private String getDocumentation(XmlSchemaAttribute xmlSchemaAttribute) {
		/*
		 * Get the documentation value from the <xs:annotation> tag, which can be persisted in Hive as a column comment
		 * Example:
		 * 
		 * <xs:attribute name="Code">
		 * 		<xs:annotation>
		 * 			<xs:documentation>This is only a test</xs:documentation>
		 * 		</xs:annotation>
		 * 		<xs:simpleType>
		 * 			<xs:restriction base="xs:string">
		 * 				<xs:minLength value="1"/>
		 * 				<xs:maxLength value="24"/>
		 * 			</xs:restriction>
		 * 		</xs:simpleType>
		 * </xs:attribute>
		 * 
		 */

		if (xmlSchemaAttribute == null)
			return null;

		XmlSchemaAnnotation annotation = xmlSchemaAttribute.getAnnotation();
		return getDocumentationBase(annotation);
	}

	private String getDecimalDataType(XmlSchemaSimpleTypeRestriction rest) {
		StringBuilder dataType = new StringBuilder(15);

		Object fractionalDigitsObj = null;
		Object totalDigitsObj = null;
		//
		// Do we have both <xs:totalDigits value="..."/> and <xs:fractionDigits value="..."/> ?
		//
		if (rest.getFacets().size() == 2) {
			XmlSchemaNumericFacet facet1 = (XmlSchemaNumericFacet) rest.getFacets().get(0);
			XmlSchemaNumericFacet facet2 = (XmlSchemaNumericFacet) rest.getFacets().get(1);
			if (facet1 instanceof XmlSchemaFractionDigitsFacet) {
				fractionalDigitsObj = facet1.getValue();
				totalDigitsObj = facet2.getValue();
			} else {
				fractionalDigitsObj = facet2.getValue();
				totalDigitsObj = facet1.getValue();
			}
		} else {
			XmlSchemaNumericFacet fdf = (XmlSchemaNumericFacet) rest.getFacets().get(0);
			if (fdf instanceof XmlSchemaFractionDigitsFacet)
				fractionalDigitsObj = fdf.getValue();
			else
				totalDigitsObj = fdf.getValue();
		}

		int fractionalDigits = 0;
		int totalDigits = 0;
		try {
			fractionalDigits = Integer.parseInt((String) fractionalDigitsObj);
		} catch (NumberFormatException nfe) {}
		try {
			totalDigits = Integer.parseInt((String) totalDigitsObj);
		} catch (NumberFormatException nfe) {}

		dataType.append("decimal(").append(totalDigits == 0 ? (fractionalDigits + 10) : totalDigits).append(",").append(fractionalDigits).append(")");

		return dataType.toString();
	}

	private void processAttributeSimpleType(String path, XmlSchemaAttribute xmlSchemaAttribute) {
		QName qName = xmlSchemaAttribute.getSchemaTypeName();
		String name = xmlSchemaAttribute.getName();

		XmlSchemaType type = this.xmlSchema.getTypeByName(qName);
		if (type == null)
			type = xmlSchemaAttribute.getSchemaType();
		if (type instanceof XmlSchemaSimpleType) {
			String xpath = path + "/" + name;
			XmlSchemaSimpleTypeRestriction rest = (XmlSchemaSimpleTypeRestriction) ((XmlSchemaSimpleType) type)
					.getContent();
			String typeName = rest != null ? rest.getBaseTypeName().getLocalPart() : null;
			if (typeName == null || typeName.equalsIgnoreCase("anySimpleType"))
				typeName = type.getName();
			String dataType = getHiveTypeFromXSDType(typeName);
			String hiveColumnName = this.getHiveNameFromXPath(isEmitUniqueXmlPath(name) ? name : xpath);
			//
			// Check to see whether there is a <xs:fractionDigits> tag. If
			// so, that gives us the number of digits after the decimal
			// point for decimal types.
			//
			if (rest != null && rest.getFacets() != null && rest.getFacets().size() > 0
					&& dataType.equalsIgnoreCase("decimal"))
				dataType = getDecimalDataType(rest);
			String listName = tableStack.peek();
			HiveColumnList tableList = hiveDDL.getList(listName);
			if (!listName.equalsIgnoreCase("parent"))
				hiveColumnName = name;

			String annotationDoc = getDocumentation(xmlSchemaAttribute);
			HiveColumn hc = new HiveColumn(hiveColumnName, dataType, typeName, xpath, annotationDoc);
			tableList.add(hc);
			hiveDDL.getTables().put(listName, tableList);
		}
	}

	private void processSimpleType(String path, XmlSchemaElement xmlSchemaElement, boolean isUnbounded) {
		QName qName = xmlSchemaElement.getSchemaTypeName();
		String name = xmlSchemaElement.getName();
		
		//System.out.println("In processSimpleType(), XML Element: " + xmlSchemaElement.getName() + ", parentTable = " + tableStack.peek());
		if (isArray(xmlSchemaElement)) {
			System.out.println(xmlSchemaElement.getName() + "  ----> simple " + qName.getLocalPart() + " type ARRAY");
		} else {
			if (xmlSchemaElement.getMaxOccurs() > 1 || isUnbounded) {
				//System.out.println("***************************** " + path + " is UNBOUNDED in processSimpleType() **********************");
				String parentTable = tableStack.peek();
				//System.out.println("parent table = " + parentTable + ", name = " + name);
				if (parentTable == null || !parentTable.equalsIgnoreCase(name)) {
					//
					// We have a new child table.
					// Push it onto the stack.
					//
					tableStack.push(name);
					//
					// Check whether child table exists
					//
					//System.out.println("Check if list " + name + " exists.");
					if (!hiveDDL.containsKey(name)) {
						//System.out.println("List " + name + " does not exist. Creating it.");
						hiveDDL.addNewList(name);
						hiveDDL.getList(name).add(new HiveColumn("uuidfk", "string", path + "/uuidfk"));
					}
					//
					// Now add a uuid to the parent table
					//
					HiveColumnList tableList = hiveDDL.getList(parentTable);
					boolean isParentTableEmpty = false;
					if (tableList == null) {
						tableList = hiveDDL.getList("parent");
						isParentTableEmpty = true;
					}

					if (parentTable.equalsIgnoreCase("parent") || isParentTableEmpty) {
						//System.out.println("Adding " + getHiveNameFromXPath(path) + "_uuid to parent");
						tableList.add(new HiveColumn(getHiveNameFromXPath(isEmitUniqueXmlPath(name) ? name : path) + "_uuid",
								"string", path, true, name));
					} else
						tableList.add(new HiveColumn(name + "_uuid", "string", path, true, name));

					// hiveDDL.getTables().put("parent", tableList);
				}

				if (name.equalsIgnoreCase(parentTable)) {
					//System.out.println("name = " + name + ", tableStack.peek() = " + tableStack.peek() + ", Popping...");
					tableStack.pop();
				}
			}

			XmlSchemaType type = this.xmlSchema.getTypeByName(qName);
			if (type == null)
				type = xmlSchemaElement.getSchemaType();
			if (type instanceof XmlSchemaSimpleType) {
				String xpath = path + "/" + name;
				XmlSchemaSimpleTypeRestriction rest = (XmlSchemaSimpleTypeRestriction) ((XmlSchemaSimpleType) type)
						.getContent();
				// String parentElement = getParentElementfromXPath(xpath);
				// System.out.println("baseTypeName = " + rest.getBaseTypeName() + ", local part = " + rest.getBaseTypeName().getLocalPart());
				// System.out.println("Calling getHiveTypeFromXSDType(" + rest.getBaseTypeName().getLocalPart() + ")");
				boolean finished = false;
				String hiveColumnName = null;
				String dataType = null;
				String typeName = null;
				do {
					/*
					 * Loop following restrictions until we hit a base type (hence the do/while construct). Example:
					 * <xs:element name="EventType">
					 * 		<xs:simpleType>
					 * 			<xs:restriction base="mt:EVENT_TYPE_TYPE">
					 * 				<xs:minLength value="1"/>
					 * 				<xs:maxLength value="30"/>
					 * 			</xs:restriction>
					 * 		</xs:simpleType>
					 * </xs:element>
					 * 
					 * <xs:simpleType name="EVENT_TYPE_TYPE">
					 * 		<xs:annotation>
					 * 			<xs:documentation>V1.0</xs:documentation>
					 * 		</xs:annotation>
					 * 		<xs:restriction base="xs:string">
					 * 			<xs:enumeration value="Mandatory"/>
					 * 			<xs:enumeration value="Voluntary"/>
					 * 			<xs:enumeration value="Other"/>
					 * 		</xs:restriction>
					 * </xs:simpleType>
					 * 
					 * Because the simpleType restriction references a base type, we have to parse the base type and discover that its restriction is <xs:string>, hence
					 * element EventType should be mapped to a string Hive column.
					 * 
					 */
					typeName = rest != null ? rest.getBaseTypeName().getLocalPart() : null;
					if (typeName == null || typeName.equalsIgnoreCase("anySimpleType"))
						typeName = type.getName();
					dataType = getHiveTypeFromXSDType(typeName);
					hiveColumnName = this.getHiveNameFromXPath(isEmitUniqueXmlPath(name) ? name : xpath);
					//
					// Check to see whether there is a <xs:fractionDigits> tag. If
					// so, that gives us the number of digits after the decimal
					// point for decimal types.
					//
					if (rest != null && rest.getFacets() != null && rest.getFacets().size() > 0) {
						if (dataType.equalsIgnoreCase("decimal")) {
							dataType = getDecimalDataType(rest);
							finished = true;
						} else {
							QName baseTypeName = rest.getBaseTypeName();
							XmlSchemaType baseType = this.xmlSchema.getTypeByName(baseTypeName);
							if (baseType != null)
								rest = (XmlSchemaSimpleTypeRestriction) ((XmlSchemaSimpleType) baseType).getContent();
							else
								finished = true;
						}
					} else
						finished = true;
				} while (!finished);
			
				String listName = tableStack.peek();
				HiveColumnList tableList = hiveDDL.getList(listName);
				if (!listName.equalsIgnoreCase("parent"))
					hiveColumnName = name;
				
				String annotationDoc = getDocumentation(xmlSchemaElement);
				if (annotationDoc == null)
					annotationDoc = getDocumentation(type);
				HiveColumn hc = new HiveColumn(hiveColumnName, dataType, typeName, xpath, annotationDoc);

				tableList.add(hc);
				hiveDDL.getTables().put(listName, tableList);
			}
		}
	}

	private boolean isArray(XmlSchemaElement element) {
		return element.getMaxOccurs() != 1;
	}
}