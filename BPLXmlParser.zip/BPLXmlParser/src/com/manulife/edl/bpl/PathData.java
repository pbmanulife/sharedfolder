/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.manulife.edl.bpl.hive.HiveColumn;
import com.manulife.edl.bpl.hive.HiveColumnList;

public class PathData {
		private Map<String, HiveColumn> xpathMap;

		public void setXpathMap(Map<String, HiveColumn> xpathMap) {
			this.xpathMap = xpathMap;
		}

		public Map<String, HiveColumnList> getTableMap() {
			Map<String, HiveColumnList> retVal = new HashMap<>();

			for (String xpath : xpathMap.keySet()) {
				HiveColumn hc = xpathMap.get(xpath);
				String tableName = hc.getTable();
				if (!retVal.containsKey(tableName)) {
					HiveColumnList lst = new HiveColumnList();
					lst.add(hc);
					retVal.put(tableName, lst);
				} else {
					HiveColumnList lst = retVal.get(tableName);
					lst.add(hc);
				}
			}

			for (String key : retVal.keySet()) {
				HiveColumnList value = retVal.get(key);
				Collections.sort(value.getList());
			}

			return retVal;
		}

		public Map<String, Integer> getNumberOfFieldsByTable() {
			Map<String, Integer> retVal = new HashMap<>();

			for (String xpath : xpathMap.keySet()) {
				HiveColumn hc = xpathMap.get(xpath);
				String tableName = hc.getTable();
				int columnNumber = hc.getColumnNumber();

				if (!retVal.containsKey(tableName))
					retVal.put(tableName, columnNumber);
				else {
					int maxColumnNumber = retVal.get(tableName);
					if (columnNumber > maxColumnNumber)
						retVal.put(tableName, columnNumber);
				}
			}

			return retVal;
		}

		public Map<String, Integer> getIndexOfFieldByTable(String fieldName) {
			Map<String, Integer> retVal = new HashMap<>();

			for (String xpath : xpathMap.keySet()) {
				HiveColumn hc = xpathMap.get(xpath);
				String tableName = hc.getTable();
				int columnNumber = hc.getColumnNumber();

				if (hc.getName().equalsIgnoreCase(fieldName) && (!retVal.containsKey(tableName)))
					retVal.put(tableName, columnNumber);
			}

			return retVal;
		}

		public HiveColumn getHiveColumnFromXPath(String xPath) {
			if (xpathMap == null)
				return null;

			xPath = xPath.trim().toLowerCase();

			HiveColumn hc = xpathMap.get(xPath);
			if (hc == null && xPath.startsWith("/"))
				hc = xpathMap.get(xPath.substring(1));

			return hc == null ? null : hc;
		}

		public int getOrderNoFromXPath(HiveColumn hc) {
			return hc == null ? -1 : hc.getColumnNumber();
		}

		public int getOrderNoFromXPath(String xPath) {
			if (xpathMap == null)
				return -1;

			HiveColumn hc = getHiveColumnFromXPath(xPath);
			return hc == null ? -1 : hc.getColumnNumber();
		}

		public String getParentTable() {
			Set<String> keys = xpathMap.keySet();
			Set<String> tableNames = new HashSet<>();
			for (String xpath : keys)
				tableNames.add(xpathMap.get(xpath).getTable());
			
			for (String tableName : keys) {
				HiveColumn hc = xpathMap.get(tableName);
				if (hc.getIsGuid())
					tableNames.remove(hc.getChildTable());
			}

			return tableNames.toArray(new String[1])[0];
		}
	}