/**
 * This class holds the contents one BPL Hive table in CSV format. Each row is represented as a map of integer keys and
 * string values. The integer key represents a Hive column number, while the string value represents the contents of the cell
 * in that column. 
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl;

import java.util.*;

public class CSVFile implements Iterable<String> {

	private List<Map<Integer, String>> rows;
	private int numberOfColumns;
	private char delimiter;
	private String nullString;
	private boolean isFieldEnclosedInQuotesFlag;

	class CSVFileIterator implements Iterator<String> {
		private int index = 0;

        public boolean hasNext() {
            return index < rows.size();
        }

        public String next() {
        	return getCsvRow(rows.get(index++)).append('\n').toString();
        }

        public void remove() {
            throw new UnsupportedOperationException("not supported yet");

        }    
	}
	
	CSVFile(char delimiter, String nullString, boolean isFieldEnclosedInQuotesFlag) {
		this.rows = new ArrayList<>();
		this.delimiter = delimiter;
		this.nullString = nullString;
		this.isFieldEnclosedInQuotesFlag = isFieldEnclosedInQuotesFlag;
	}	

	public List<Map<Integer, String>> getRows() {
		return this.rows;
	}

	public int getSize() {
		return (this.rows == null) ? 0 : this.rows.size();
	}

	public Map<Integer, String> get(int index) {
		if (this.rows.size() == 0)
			return null;
		
		try {
			return this.rows.get(index);
		} catch (IndexOutOfBoundsException ie) {
			return null;
		}
	}

	public void add(int index, Map<Integer, String> e) {
		this.rows.add(index, e);
	}

	public void setNumberOfColumns(int numberOfColumns) {
		this.numberOfColumns = numberOfColumns;
	}

	public void setColumnValue(int columnIndex, String value) {
		for (Map<Integer, String> row : rows)
			row.put(columnIndex, value);
	}

	public void setDelimiter(char delimiter) {
		this.delimiter = delimiter;
	}

	private StringBuilder getCsvRow(String[] columns) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columns.length; i++) {
			if (isFieldEnclosedInQuotesFlag) {
				//
				// Check for backslash in the value of each CSV field. Backslashes must be escaped.
				//
				if (columns[i] != null && columns[i].contains("\\"))
					columns[i] = columns[i].replace("\\", "\\\\");
				//
				// Check for double-quotes in the value of each CSV field. Double-quotes must be escaped.
				//
				if (columns[i] != null && columns[i].contains("\""))
					columns[i] = columns[i].replaceAll("\"", "\\\\\"");

				sb.append('"').append(columns[i] == null ? nullString : columns[i]).append('"');
			} else {
				sb.append(columns[i] == null ? nullString : columns[i]);
			}

			if (i != (columns.length - 1))
				sb.append(delimiter);	
		}

		return sb;
	}

	private StringBuilder getCsvRow(Map<Integer, String> columnsMap) {
		//
		// columnsMap --> (key, value) where key = columnIndex and value = obvious.
		//
		String[] columns = new String[this.numberOfColumns];
		for (int index : columnsMap.keySet()) {
			if (index >= 0)
				columns[index] = columnsMap.get(index);
		}

		return getCsvRow(columns); 
	}

	public String debug() {
		StringBuilder sb = new StringBuilder();

		for (int row = 0; row < rows.size(); row++) {
			Map<Integer, String> rowValuesMap = rows.get(row);
			sb.append("Row[" + row + "]\n");
			for (int columnIndex : rowValuesMap.keySet()) {
				String value = rowValuesMap.get(columnIndex);
				sb.append("Column [" + columnIndex + "] = " + value + "\n");
			}
		}

		return sb.toString();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		for (Map<Integer, String> rowValuesMap : rows)
			sb.append(getCsvRow(rowValuesMap)).append('\n');

		return sb.toString();
	}

	@Override
    public Iterator<String> iterator() {
        return new CSVFileIterator();
    }
}
