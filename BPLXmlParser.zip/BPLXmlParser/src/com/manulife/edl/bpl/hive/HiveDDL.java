/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl.hive;

import java.util.*;

import com.manulife.edl.bpl.Constants;
import com.manulife.edl.bpl.util.DateUtils;

public class HiveDDL {

	private static final String SEPARATOR = "^^^^^^^^^^SEPARATOR";
	private static final String DELIM = "|";

	private Map<String, HiveColumnList> tables;
	private String hiveDB;
	private String hiveParentTable;
	private String fileFormat;
	private boolean isRawTable;
	private boolean isRawTablePartitioned;
	private String rawPartitionFieldName;
	private String rawPartitionFieldType;
	private boolean isTypedTablePartitioned;
	private String typedPartitionFieldName;
	private String typedPartitionFieldType;
	private boolean isTypedTablesClustered;
	private String typedClusteringFieldName;
	private int numClusteringBuckets;
	private String baseHdfsLocation;
	private String delimiterText;

	public HiveDDL() {
		this.tables = new HashMap<>();
	}

	public HiveDDL(Map<String, HiveColumnList> tables) {
		this.tables = tables;
	}

	public HiveDDL(String hiveDB, String hiveParentTable) {
		super();
		this.hiveDB = hiveDB;
		this.hiveParentTable = hiveParentTable;
	}

	public void setHiveDB(String hiveDB) {
		this.hiveDB = hiveDB;
	}

	public void setHiveParentTable(String hiveParentTable) {
		this.hiveParentTable = hiveParentTable;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public void setIsRawTable(boolean isRawTable) {
		this.isRawTable = isRawTable;
	}

	public void setIsRawTablePartitioned(boolean isRawTablePartitioned) {
		this.isRawTablePartitioned = isRawTablePartitioned;
	}

	public void setRawPartitionFieldName(String rawPartitionFieldName) {
		this.rawPartitionFieldName = rawPartitionFieldName;
	}

	public void setRawPartitionFieldType(String rawPartitionFieldType) {
		this.rawPartitionFieldType = rawPartitionFieldType;
	}

	public void setIsTypedTablePartitioned(boolean isTypedTablePartitioned) {
		this.isTypedTablePartitioned = isTypedTablePartitioned;
	}

	public void setTypedPartitionFieldName(String typedPartitionFieldName) {
		this.typedPartitionFieldName = typedPartitionFieldName;
	}

	public void setTypedPartitionFieldType(String typedPartitionFieldType) {
		this.typedPartitionFieldType = typedPartitionFieldType;
	}

	public void setTypedClusteringFieldName(String typedClusteringFieldName) {
		this.typedClusteringFieldName = typedClusteringFieldName;
	}

	public void setIsTypedTablesClustered(boolean isTypedTablesClustered) {
		this.isTypedTablesClustered = isTypedTablesClustered;
	}

	public void setTypedNumClusteringBuckets(int numClusteringBuckets) {
		this.numClusteringBuckets = numClusteringBuckets;
	}

	public void setBaseHdfsLocation(String baseHdfsLocation) {
		this.baseHdfsLocation = baseHdfsLocation;
	}

	public void setDelimiterText(String delimiterText) {
		this.delimiterText = delimiterText;
	}

	public boolean containsKey(String key) {
		return tables.containsKey(key);
	}

	public HiveColumnList getList(String key) {
		if (tables.containsKey(key))
			return tables.get(key);
		else
			return new HiveColumnList();
	}

	public void addNewList(String key) {
		tables.put(key, new HiveColumnList());
	}

	public Map<String, HiveColumnList> getTables() {
		return this.tables;
	}

	public int getIndexOfFirstOccurrence(HiveColumnList lst, String name) {
		if (name == null || name.trim().length() == 0)
			return -1;
		else
			name = name.toLowerCase();

		Map<String, Integer> columnNameVsIndexesMap = new HashMap<>();
		int index = 0;
		for (HiveColumn hc : lst.getList()) {
			String columnName = hc.getName().toLowerCase();
			if (!columnNameVsIndexesMap.containsKey(columnName))
				columnNameVsIndexesMap.put(columnName, index++);
		}

		return columnNameVsIndexesMap.containsKey(name) ? columnNameVsIndexesMap.get(name) : 0;
	}

	public int getIndexOfLastColumn(HiveColumnList lst) {
		Set<String> uniqueColumnNames = new HashSet<>();
		for (int i = 0; i < lst.size(); i++) {
			HiveColumn hc = lst.get(i);
			uniqueColumnNames.add(hc.getName());
		}

		return uniqueColumnNames.size() - 1;
	}

	public String getPaths(boolean isXsdUpdate) {
		StringBuilder sb = new StringBuilder();

		sb.append(SEPARATOR).append('\n');
		for (String s : tables.keySet()) {
			HiveColumnList hiveColumnList = tables.get(s);
			for (int i = 0; i < hiveColumnList.size(); i++) {
				HiveColumn hc = hiveColumnList.get(i);
				String currentTable = "";
				String childTable = "";

				if (!isXsdUpdate) {
					currentTable = (s.equalsIgnoreCase("parent") ? hiveParentTable : hiveParentTable + "_" + s).toLowerCase();
					childTable = hc.getChildTable().trim().length() == 0 ? "" :
						(hiveParentTable + "_" + hc.getChildTable()).toLowerCase();
				} else {
					currentTable = s.toLowerCase();
					childTable = hc.getChildTable().trim().length() == 0 ? "" :
						hc.getChildTable().toLowerCase();
					if (!childTable.startsWith(hiveParentTable + "_") && childTable.length() > 0)
						childTable = hiveParentTable + "_" + childTable;
				}
				
				String columnName = hc.getName().toLowerCase();
				int firstIndex = getIndexOfFirstOccurrence(hiveColumnList, columnName);
				for (String xp : hc.getXpath()) {
					if ((i == hiveColumnList.size() - 1) && !s.equalsIgnoreCase("parent"))
						sb.append(currentTable).append(DELIM).append(columnName).append(DELIM).append(hc.getType()).append(DELIM).append(
								xp.toLowerCase()).append(DELIM).append(getIndexOfLastColumn(hiveColumnList)).append(DELIM).append(
										hc.getIsGuid()).append(DELIM).append(childTable).append("\n");
					else
						sb.append(currentTable).append(DELIM).append(columnName).append(DELIM).append(hc.getType()).append(DELIM).append(
								xp.toLowerCase()).append(DELIM).append(firstIndex).append(DELIM).append(
										hc.getIsGuid()).append(DELIM).append(childTable).append("\n");
				}
			}
		}

		return sb.toString();
	}
    
	public String getInsert() {
		StringBuilder sb = new StringBuilder().append(SEPARATOR).append('\n').append(
				"INSERT INTO " + hiveParentTable + "\nSELECT\n");

		for (String s : tables.keySet()) {
			if (!s.equalsIgnoreCase("parent"))
				continue;
			HiveColumnList hiveColumnList = tables.get(s);
			for (int i = 0; i < hiveColumnList.size(); i++) {
				HiveColumn hc = hiveColumnList.get(i);
				String columnType = hc.getType().toLowerCase();
				if (columnType.startsWith("decimal"))
					columnType = "decimal";
				if (columnType.startsWith("varchar"))
					columnType = "varchar";
				switch (columnType) {
					case "int":
					case "bigint":
						if (i == hiveColumnList.size() - 1)
							sb.append("    ").append(i+1).append("\n");
						else
							sb.append("    ").append(i+1).append(",\n");
						break;
					case "decimal":
					case "double":
						if (i == hiveColumnList.size() - 1)
							sb.append("    ").append(i+1).append(".0\n");
						else
							sb.append("    ").append(i+1).append(".0,\n");
						break;
					case "string":
					case "char":
					case "varchar":
						if (i == hiveColumnList.size() - 1)
							sb.append("    '").append(i+1).append("'\n");
						else
							sb.append("    '").append(i+1).append("',\n");
						break;
					case "boolean":
						if (i == hiveColumnList.size() - 1)
							sb.append("    true\n");
						else
							sb.append("    true,\n");
						break;
					case "date":
						Date today = new Date();
						if (i == hiveColumnList.size() - 1)
							sb.append("    '").append(DateUtils.getStringFromDate(today)).append("'\n");
						else
							sb.append("    '").append(DateUtils.getStringFromDate(today)).append("',\n");
						break;
					case "timestamp":
						today = new Date();
						if (i == hiveColumnList.size() - 1)
							sb.append("    '").append(DateUtils.getStringFromTimestampUTC(today)).append("'\n");
						else
							sb.append("    '").append(DateUtils.getStringFromTimestampUTC(today)).append("',\n");
						break;
					default:
						sb.append(columnType + " IS WTF???");
				}
				//System.out.println(columnName + " --> " + hc.getType());
			}
		}

		return sb.toString();
	}

    public void addBusinessTimestampFields() {
    	HiveColumnList masterTable = tables.get("parent");
    	if (masterTable != null && masterTable.size() > 0) {
    		masterTable.add(new HiveColumn("publication_time", "timestamp", "publication_time"));
    		masterTable.add(new HiveColumn("business_date", "date", "business_date"));
    	}
    }

	public void addSourceFile() {
		if (tables != null) {
			for (String table : tables.keySet()) {
				HiveColumnList hiveColumnList = tables.get(table);
				if (table != null && table.equalsIgnoreCase("parent"))
					hiveColumnList.add(new HiveColumn(Constants.SOURCE_FILE, "string", hiveParentTable + "/" + Constants.SOURCE_FILE));
				else
					hiveColumnList.add(new HiveColumn(Constants.SOURCE_FILE, "string", table + "/" + Constants.SOURCE_FILE));
			}
		}
	}

	public void addIngestionTimestamp() {
		if (tables != null) {
			for (String table : tables.keySet()) {
				HiveColumnList hiveColumnList = tables.get(table);
				if (table != null && table.equalsIgnoreCase("parent"))
					hiveColumnList.add(new HiveColumn(Constants.PROCESS_TIMESTAMP, "timestamp", hiveParentTable + "/" + Constants.PROCESS_TIMESTAMP));
				else
					hiveColumnList.add(new HiveColumn(Constants.PROCESS_TIMESTAMP, "timestamp", table + "/" + Constants.PROCESS_TIMESTAMP));
			}
		}
	}

	public static StringBuilder getAlterTableAddStatement(String db, String tableName, HiveColumnList lst) {
		StringBuilder sb = new StringBuilder();
		sb.append(SEPARATOR).append('\n');
		if (lst != null && lst.size() > 0) {
			sb.append("ALTER TABLE ").append(db).append('.').append(tableName).append(" ADD COLUMNS (\n");
			for (int i = 0; i < lst.size(); i++) {
				HiveColumn hc = lst.get(i);
				sb.append("    `").append(hc.getName().toLowerCase()).append("` ").append(hc.getType());
				String comment = hc.getNormalizedComment();
				if (comment == null || comment.trim().length() == 0)
					sb.append(" COMMENT 'Added ").append(new Date().toString()).append("'");
				else
					sb.append(" COMMENT '").append(comment).append('\'');

				if (i < lst.size() - 1)
					sb.append(",\n");
			}
			sb.append("\n)");
		}

		return sb;
	}

	//ALTER TABLE name CHANGE column_name new_name new_type
	public static StringBuilder getAlterTableChangeStatement(String db, String tableName, HiveColumnList lst) {
		StringBuilder sb = new StringBuilder();
		sb.append(SEPARATOR).append('\n');
		if (lst != null && lst.size() > 0) {
			for (HiveColumn hc : lst.getList()) {
				sb.append("ALTER TABLE ").append(db).append('.').append(tableName).append(" CHANGE ");
				sb.append('`').append(hc.getName().toLowerCase()).append("` ").
					append('`').append(hc.getName().toLowerCase()).append("` ").append(hc.getType());
			}
		}

		return sb;
	}

	private StringBuilder getDropTableStatement(String db, String tableName) {
		StringBuilder sb = new StringBuilder();
		sb.append(SEPARATOR).append('\n');
		sb.append("DROP TABLE IF EXISTS ").append(db).append('.').append(tableName).append(" PURGE\n");
		sb.append(SEPARATOR).append('\n');

		return sb;
	}

	private StringBuilder getDropViewStatement(String db, String viewName) {
		StringBuilder sb = new StringBuilder();
		sb.append(SEPARATOR).append('\n');
		sb.append("DROP VIEW IF EXISTS ").append(db).append('.').append(viewName).append('\n');
		sb.append(SEPARATOR).append('\n');

		return sb;
	}
	
	private String getHdfsLocation(String tableName) {
		//
		// HDFS location = /user/inv/raw/certifed/[SOURCE]/[TOPIC]/temp/<PARENT-TABLE>/<TABLE_NAME>
		// this.baseHdfsLocation = /user/inv/raw/certifed/[SOURCE]/[TOPIC]/temp/
		//
		StringBuilder sb = new StringBuilder(this.baseHdfsLocation).append('/').append(this.hiveParentTable).append('/').append(tableName);

		return sb.toString().toLowerCase();
	}
	
	public String getCastedHiveView(String hiveDB, boolean isXsdUpdate, boolean isUseHiveCurrentTimestamp,
			String hiveCurrentTimestampZone, Set<String> changedTables) {
		//
		// Emits DDL for a Hive view that issues CASTs to move String data from inv_raw to typed data in inv_typed.
		//
		StringBuilder sb = new StringBuilder();

		for (String s : tables.keySet()) {
			if (s == null || s.trim().length() == 0)
				continue;

			if (isXsdUpdate && !changedTables.contains(s))
				continue;

			HiveColumnList hiveColumnList = tables.get(s);
			String currentTable = "";
			if (!isXsdUpdate)
				currentTable = (s.equalsIgnoreCase("parent") ? hiveParentTable : hiveParentTable + "_" + s).toLowerCase();
			else
				currentTable = s.toLowerCase();
			String currentView = "vw_" + currentTable;

			sb.append(getDropViewStatement(hiveDB, currentView));
			sb.append("CREATE VIEW IF NOT EXISTS ").append(hiveDB).append('.').append(currentView).append(" AS\nSELECT\n");
			
			Set<String> uniqueColumnsNames = new HashSet<String>();
			for (int i = 0; i < hiveColumnList.size(); i++) {
				HiveColumn hc = hiveColumnList.get(i);
				String columnName = hc.getName().toLowerCase();

				if (!uniqueColumnsNames.contains(columnName)) {
					uniqueColumnsNames.add(columnName);
					sb.append("    ");

					switch (hc.getType().toLowerCase()) {
						case "string":
							sb.append("IF (`").append(columnName).append("` = '\\\\n', NULL, `").append(columnName).append(
									"`) AS ").append(columnName);
							break;

						case "boolean":
							sb.append("CAST(CASE WHEN `").append(columnName).append("` IS NULL THEN NULL WHEN `").append(columnName).
								append("` = '\\\\n' THEN NULL WHEN TRIM(LOWER(`").append(columnName).append(
										"`)) = 'true' THEN 1 ELSE 0 END AS boolean) AS ").append(hc.getName());
							break;

						case "date":
							sb.append("CAST(IF (`").append(columnName).append("` = '\\\\n', NULL, TO_DATE(from_unixtime(unix_timestamp(`").append(
									columnName).append("`, '").append(DateUtils.DATE_FORMAT).append("')))) AS date) AS `").append(columnName).append('`');
							break;

						case "timestamp":
							//
							// Check whether this field is defined as <xs:dateTime> in the XSD.
							// These dateTime fields appear to have an ISO format in the payload with a letter T
							//
							if (hc.getXsdType() != null && hc.getXsdType().equalsIgnoreCase("datetime"))
								sb.append("IF (`").append(columnName).append("` = '\\\\n', NULL, CAST(regexp_replace(`").append(
										columnName).append("`, 'T', ' ') AS TIMESTAMP)) AS `").append(columnName).append('`');
							else if (isUseHiveCurrentTimestamp && columnName.equalsIgnoreCase(Constants.PROCESS_TIMESTAMP)) {
								if (hiveCurrentTimestampZone == null)
									sb.append("current_timestamp AS `").append(columnName).append('`');
								else
									sb.append("to_utc_timestamp(current_timestamp, '").append(hiveCurrentTimestampZone).append("') AS `").append(columnName).append('`');
									
							} else
								sb.append("IF (`").append(columnName).append("` = '\\\\n', NULL, from_unixtime(unix_timestamp(`").append(
										columnName).append("`, '").append(DateUtils.DATETIME_FORMAT).append("'))) AS `").append(
												columnName).append('`');
							break;

						default:
							sb.append("CAST(IF (`").append(columnName).append("` = '\\\\n', NULL, `").append(columnName).append(
									"`) AS ").append(hc.getType()).append(")");
							break;
					}

					sb.append((i != hiveColumnList.size() - 1) ? ",\n" : "\n");
				}
			}
			//
			// If table is partitioned, we need the partition column in the view
			//
			if (this.isRawTable && this.isRawTablePartitioned)
				sb.append("    ,`").append(this.rawPartitionFieldName).append("`\n");

			sb.append("FROM ").append(hiveDB).append('.').append(currentTable).append("\n");
		}

		return sb.toString();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		//sb.append("Number of lists in map: " + tables.size() + "\n");
		for (String s : tables.keySet()) {
			if (s == null || s.trim().length() == 0)
				continue;

			HiveColumnList hiveColumnList = tables.get(s);
			String currentTable = (s.equalsIgnoreCase("parent") ? hiveParentTable : hiveParentTable + "_" + s).toLowerCase();

			sb.append(getDropTableStatement(hiveDB, currentTable));
			sb.append("CREATE ").append(this.isRawTable ? "EXTERNAL " : "").append("TABLE IF NOT EXISTS ").append(
					hiveDB).append('.').append(currentTable).append(" (\n");

			Set<String> uniqueColumnsNames = new HashSet<String>();
			for (int i = 0; i < hiveColumnList.size(); i++) {
				HiveColumn hc = hiveColumnList.get(i);
				String columnName = hc.getName();

				if (!uniqueColumnsNames.contains(columnName.toLowerCase())) {
					sb.append(hc.toString());
					sb.append((i != hiveColumnList.size() - 1) ? ",\n" : "\n)\n");
					uniqueColumnsNames.add(columnName.toLowerCase());
				}
			}
			//
			// Add table creation timestamp to table comment (might be helpful later)
			//
			sb.append("COMMENT 'Created ").append(new Date().toString()).append("'\n");
			//
			// Partition external table
			//
			if (this.isRawTable && this.isRawTablePartitioned)
				sb.append("PARTITIONED BY (").append(this.rawPartitionFieldName).append(" ").append(
						this.rawPartitionFieldType).append(")\n");
			else if (!this.isRawTable && this.isTypedTablePartitioned)
				sb.append("PARTITIONED BY (").append(this.typedPartitionFieldName).append(" ").append(
						this.typedPartitionFieldType).append(")\n");
			//
			// Bucket table
			//
			if (!this.isRawTable && this.isTypedTablesClustered && s.equalsIgnoreCase("parent"))
				sb.append("CLUSTERED BY (").append(this.typedClusteringFieldName).append(") INTO ").append(this.numClusteringBuckets).append(" BUCKETS\n");
			//
			// Add storage format (ORC for managed tables, TEXTFILE for raw tables)
			//
			if (fileFormat == null || fileFormat.toLowerCase().indexOf("textfile") > -1) {
				sb.append("ROW FORMAT DELIMITED\n");
				sb.append("FIELDS TERMINATED BY '").append(delimiterText).append("'\n");
				sb.append("STORED AS TEXTFILE\n");
				sb.append("LOCATION '").append(getHdfsLocation(currentTable)).append("'\n");
			} else
				sb.append("STORED AS ORC\n");
			//
			// Make sure table is purged, not moved to the trash, when the table is dropped. This prevents encrypted tables from winding up in
			// unencrypted trash space.
			//
			sb.append("TBLPROPERTIES (\"auto.purge\"=\"true\")\n");
		}
		
		return sb.toString();
	}
}
