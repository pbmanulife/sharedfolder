/**
 * 
 * @author  Edward Wiener
 * @company NEOS LLC
 * @version 1.0
 * 
*/
package com.manulife.edl.bpl.hive;

import java.util.ArrayList;
import java.util.List;

public class HiveColumn implements Comparable<HiveColumn> {
	private String table;
	private String name;
	private String type;
	private String xsdType;
	private String comment;
	private List<String> xpath;
	private int columnNumber;
	private boolean isGuid;
	private String childTable;

	public HiveColumn(String name, String type, String xpath) {
		this.name = name;
		this.type = type;

		if (this.xpath == null)
			this.xpath = new ArrayList<String>();
		this.xpath.add(xpath);
	}

	public HiveColumn(String name, String type, String xsdType, String xpath) {
		this(name, type, xpath);
		this.xsdType = xsdType;
	}

	public HiveColumn(String name, String type, String xsdType, String xpath, String comment) {
		this(name, type, xsdType, xpath);
		this.comment = comment;
	}

	public HiveColumn(String name, String type, String xpath, boolean isGuid, String childTable) {
		this(name, type, xpath);
		this.isGuid = isGuid;
		this.childTable = childTable;
	}

	public HiveColumn(String table, String name, String type, String xpath, int columnNumber,
			boolean isGuid, String childTable) {
		this(name, type, xpath);
		this.table = table;
		this.columnNumber = columnNumber;
		this.isGuid = isGuid;
		this.childTable = childTable;
	}

	public String getTable() {
		return this.table;
	}

	public String getName() {
		return this.name;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getXsdType() {
		return this.xsdType;
	}

	public String getNormalizedComment() {
		return normalizeComment(this.comment);
	}
	
	public List<String> getXpath() {
		return this.xpath;
	}

	public int getColumnNumber() {
		return this.columnNumber;
	}

	public boolean getIsGuid() {
		return this.isGuid;
	}

	public String getChildTable() {
		return this.childTable == null ? "" : this.childTable;
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
	    if (obj == null)
	        return false;

	    if (obj instanceof HiveColumn) {
	    	HiveColumn hc = (HiveColumn) obj;
	    	return this.name.equals(hc.name);
	    }

	    return false;
	}

	@Override
	public String toString() {
		//return "    `" +  this.name.toLowerCase() + "` " + this.type;

		StringBuilder bld = new StringBuilder(20);
		bld.append("    `").append(this.name.toLowerCase()).append("` ").append(this.type);
		if (this.comment != null)
			bld.append(" COMMENT ").append('\'').append(normalizeComment(this.comment)).append('\'');

		return bld.toString();
	}

	@Override
	public int compareTo(HiveColumn a) {
		return this.columnNumber - a.getColumnNumber();
	}

	private String normalizeComment(String comment) {
		if (comment == null)
			return null;

		return comment.replaceAll(";", ",").replaceAll("\'", "").replaceAll("[\r\n\\s]+", " ").trim();
	}
}