package com.manulife.edl.bpl.hive;

import java.util.ArrayList;
import java.util.List;

public class HiveColumnList {

	private List<HiveColumn> list;

	public HiveColumnList() {
		this.list = new ArrayList<HiveColumn>();
	}

	public HiveColumnList(List<HiveColumn> list) {
		this.list = list;
	}

	public List<HiveColumn> getList() {
		return this.list;
	}

	public int size() {
		return list.size();
	}

	public HiveColumn get(int i) {
		return list.get(i);
	}

	public void add(HiveColumn hc) {
		if (list == null)
			list = new ArrayList<HiveColumn>();

		boolean isFound = false;
		for (HiveColumn h : list) {
			if (h.equals(hc)) {
				for (String xpath : hc.getXpath()) {
					if (!h.getXpath().contains(xpath))
						h.getXpath().add(xpath);
				}
				isFound = true;
				break;
			}
		}

		if (!isFound)
			list.add(hc);
	}
}
